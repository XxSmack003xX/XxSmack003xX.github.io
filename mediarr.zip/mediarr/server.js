/* MEDIARR — zero-dependency Node server
 * Serves the web app, stores Radarr/Sonarr credentials on disk (config.json),
 * and proxies all API calls so the browser never hits CORS / mixed-content issues.
 *
 * Run:  node server.js     (optionally PORT=xxxx node server.js)
 */
'use strict';
const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');
const os    = require('os');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');
const { URL } = require('url');

// Optional: detect ffmpeg/ffprobe once at startup. Used only for transcoding playback (5.1/AC3/DTS → AAC, HEVC/H.265 → H.264).
let FFMPEG = null, FFPROBE = null;
try { const r = spawnSync('ffmpeg', ['-hide_banner', '-version']); if (!r.error && r.status === 0) FFMPEG = 'ffmpeg'; } catch (e) { FFMPEG = null; }
try { const r = spawnSync('ffprobe', ['-hide_banner', '-version']); if (!r.error && r.status === 0) FFPROBE = 'ffprobe'; } catch (e) { FFPROBE = null; }

// Detect a working H.264 hardware encoder by actually test-encoding a tiny clip (safe: only used if it succeeds).
let HWENC = null;
function probeEncoder (rcArgs) {
  try {
    const r = spawnSync(FFMPEG, ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc=size=256x144:rate=5:duration=1'].concat(rcArgs, ['-f', 'null', '-']), { timeout: 8000, stdio: 'ignore' });
    return !r.error && r.status === 0;
  } catch (e) { return false; }
}
function detectHwEncoder () {
  if (!FFMPEG) return;
  const candidates = [
    ['h264_nvenc', ['-c:v', 'h264_nvenc', '-preset', 'p5', '-rc', 'vbr', '-cq', '23', '-b:v', '0']],
    ['h264_qsv', ['-c:v', 'h264_qsv', '-preset', 'veryfast', '-global_quality', '23', '-pix_fmt', 'nv12']],
    ['h264_videotoolbox', ['-c:v', 'h264_videotoolbox', '-b:v', '2M']]
  ];
  for (const [enc, rc] of candidates) { if (probeEncoder(rc)) { HWENC = enc; break; } }
  if (HWENC) { try { console.log('[mediarr] hardware video encoder detected: ' + HWENC); } catch (e) {} }
}
detectHwEncoder();
const ENC_PRESET = { balanced: 'veryfast', faster: 'superfast', fastest: 'ultrafast', quality: 'fast' };

// HLS transcode sessions (used for iPhone/iPad, which only reliably play transcoded streams via HLS).
const HLS_ROOT = path.join(os.tmpdir(), 'mediarr-hls');
const hlsSessions = new Map();   // sid -> { dir, ff, last, closed }
try { fs.rmSync(HLS_ROOT, { recursive: true, force: true }); } catch (e) {}
try { fs.mkdirSync(HLS_ROOT, { recursive: true }); } catch (e) {}
function hlsCleanup (sid) {
  const s = hlsSessions.get(sid); if (!s) return;
  try { s.ff.kill('SIGKILL'); } catch (e) {}
  try { fs.rmSync(s.dir, { recursive: true, force: true }); } catch (e) {}
  hlsSessions.delete(sid);
}
setInterval(() => { const now = Date.now(); for (const [sid, s] of hlsSessions) { if (now - s.last > 120000) hlsCleanup(sid); } }, 30000).unref();

const PORT        = process.env.PORT || 7575;
const HOST        = process.env.HOST || '0.0.0.0';
const ROOT        = __dirname;
const PUBLIC_DIR  = path.join(ROOT, 'public');
const CONFIG_PATH = path.join(ROOT, 'config.json');
const HEALTH_PATH = path.join(ROOT, 'health.json');
const USERS_PATH  = path.join(ROOT, 'users.json');
const ADDS_PATH   = path.join(ROOT, 'adds.json');
const FAVS_PATH   = path.join(ROOT, 'favorites.json');
const AUTOADD_PATH = path.join(ROOT, 'autoadd.json');
const CINEMETA    = 'https://v3-cinemeta.strem.io';
const TMDB        = 'https://api.themoviedb.org/3';
const HEALTH_INTERVAL_MS = 60 * 1000;   // background check cadence
const MAX_EVENTS  = 300;                // cap stored outage events
const SESSION_MS  = (Number(process.env.SESSION_HOURS) || 1) * 3600 * 1000;   // login token lifetime (default 1 hour)
const MAX_ADDS_LOG = 3000;

const DEFAULT_CONFIG = {
  radarr: { url: '', apiKey: '', qualityProfileId: '', rootFolderPath: '' },
  sonarr: { url: '', apiKey: '', qualityProfileId: '', rootFolderPath: '' },
  tmdb:   { apiKey: '' },
  plex:   { url: '', token: '', clientId: '' },
  webdav: { url: '', username: '', password: '', folder: '', mode: 'redirect', transcode: false, encSpeed: 'balanced', hwAccel: 'auto' },   // encSpeed: balanced|faster|fastest|quality; hwAccel: auto|off
  ui:     { loginTheme: 'tron' },  // login background theme: 'tron' | 'earth' | 'rain' | 'random'
  donate: { url: '', label: '' },  // PayPal donate link; when set, a Donate button appears for everyone
  autoAdd: { intervalMinutes: 5, minRuntime: 0 }  // minutes between each add; minRuntime = skip titles shorter than this (0 = off)
};
const LOGIN_THEMES = ['tron', 'earth', 'rain', 'random'];

/* ---------- config persistence ---------- */
function readConfig () {
  try {
    const c = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    return {
      radarr: Object.assign({}, DEFAULT_CONFIG.radarr, c.radarr),
      sonarr: Object.assign({}, DEFAULT_CONFIG.sonarr, c.sonarr),
      tmdb:   Object.assign({}, DEFAULT_CONFIG.tmdb, c.tmdb),
      plex:   Object.assign({}, DEFAULT_CONFIG.plex, c.plex),
      webdav: Object.assign({}, DEFAULT_CONFIG.webdav, c.webdav),
      ui:     Object.assign({}, DEFAULT_CONFIG.ui, c.ui),
      donate: Object.assign({}, DEFAULT_CONFIG.donate, c.donate),
      autoAdd: Object.assign({}, DEFAULT_CONFIG.autoAdd, c.autoAdd)
    };
  } catch (e) {
    return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  }
}
function writeConfig (c) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(c, null, 2));
}
// Never send raw API keys back to the browser.
function sanitize (c) {
  const out = {};
  for (const svc of ['radarr', 'sonarr']) {
    out[svc] = {
      url: c[svc].url,
      hasKey: !!c[svc].apiKey,
      qualityProfileId: c[svc].qualityProfileId,
      rootFolderPath: c[svc].rootFolderPath
    };
  }
  out.tmdb = { hasKey: !!c.tmdb.apiKey };
  out.plex = { url: c.plex.url, hasKey: !!c.plex.token };
  out.webdav = { url: c.webdav.url, username: c.webdav.username, folder: c.webdav.folder, mode: wmode(c.webdav.mode), transcode: !!c.webdav.transcode, ffmpeg: !!FFMPEG, hasAuth: !!(c.webdav.username && c.webdav.password), encSpeed: c.webdav.encSpeed || 'balanced', hwAccel: c.webdav.hwAccel || 'auto', hwEncoder: HWENC || '' };
  out.ui = { loginTheme: (c.ui && c.ui.loginTheme) || 'tron' };
  out.donate = { url: (c.donate && c.donate.url) || '', label: (c.donate && c.donate.label) || '' };
  out.autoAdd = { intervalMinutes: (c.autoAdd && c.autoAdd.intervalMinutes != null) ? Number(c.autoAdd.intervalMinutes) : 5,
                  minRuntime: (c.autoAdd && c.autoAdd.minRuntime != null) ? Number(c.autoAdd.minRuntime) : 0 };
  return out;
}
function normUrl (u) { return (u || '').trim().replace(/\/+$/, ''); }

/* ---------- Plex sign-in (OAuth PIN flow) ---------- */
// A stable client identifier is required across pin creation, authorization and polling.
function ensurePlexClientId () {
  const c = readConfig();
  if (c.plex.clientId && /^[a-f0-9-]{16,}$/i.test(c.plex.clientId)) return c.plex.clientId;
  const id = (crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex'));
  c.plex.clientId = id; writeConfig(c);
  return id;
}
function plexHeaders (clientId, token) {
  const h = {
    'X-Plex-Product': 'MEDIARR',
    'X-Plex-Version': appVersionSafe(),
    'X-Plex-Client-Identifier': clientId,
    'X-Plex-Device': 'MEDIARR',
    'X-Plex-Platform': 'Web',
    'Accept': 'application/json'
  };
  if (token) h['X-Plex-Token'] = token;
  return h;
}
function appVersionSafe () { try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version || '1.0'; } catch (e) { return '1.0'; } }

/* ---------- per-user Plex account (watchlist / history / stats) ---------- */
const PLEX_DISCOVER = 'https://discover.provider.plex.tv';
const PLEX_METADATA = 'https://metadata.provider.plex.tv';
function getUserPlex (username) { const u = findUser(username); return (u && u.plex) || null; }
function setUserPlex (username, plex) {
  const data = readUsers();
  const u = data.users.find(x => x.username.toLowerCase() === String(username).toLowerCase());
  if (!u) return false;
  if (plex) u.plex = plex; else delete u.plex;
  writeUsers(data); return true;
}
// Some plex.tv endpoints answer XML no matter what Accept says, so keep the raw text
// and parse attributes when JSON isn't available.
function xmlAttrs (text, tag) {
  const out = [];
  const re = new RegExp('<' + tag + '\\b([^>]*?)\\/?>', 'gi');
  let m;
  while ((m = re.exec(text))) {
    const attrs = {}; const are = /([A-Za-z0-9_:-]+)\s*=\s*"([^"]*)"/g; let a;
    while ((a = are.exec(m[1]))) attrs[a[1]] = a[2].replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
    out.push(attrs);
  }
  return out;
}
async function plexJson (url, token, method) {
  try {
    const up = await upstream(url, { method: method || 'GET', headers: plexHeaders(ensurePlexClientId(), token) });
    const txt = up.body ? up.body.toString('utf8') : '';
    let data = null;
    if (txt && txt.trim()[0] !== '<') { try { data = JSON.parse(txt); } catch (_) {} }
    if (up.status < 200 || up.status >= 300) {
      let msg = '';
      if (data) msg = (data.Error && data.Error.message) || data.message || '';
      if (!msg && txt) msg = txt.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 160);
      return { ok: false, status: up.status, message: msg, text: txt };
    }
    return { ok: true, data: data || {}, text: txt };
  } catch (e) { return { ok: false, status: 0, message: e.message, text: '' }; }
}
function plexErr (r, what) {
  return what + ' (HTTP ' + r.status + (r.message ? ': ' + r.message : '') + ')';
}
function plexItemsFrom (data) {
  const mc = (data && data.MediaContainer) || {};
  return mc.Metadata || [];
}
// Plex's watchlist actions key off the last segment of the item GUID
// (e.g. plex://movie/5d776be17a53e9001e732ab9 -> 5d776be17a53e9001e732ab9).
function plexActionKey (m) {
  if (m && m.guid) { const seg = String(m.guid).split('/').filter(Boolean).pop(); if (seg) return seg; }
  return (m && m.ratingKey) || '';
}
// Normalise a Plex item into what the UI needs (with proxied artwork).
function plexCard (m, host) {
  const thumb = m.thumb || m.grandparentThumb || m.parentThumb || '';
  return {
    ratingKey: plexActionKey(m), guid: m.guid || '',
    type: m.type || '', title: m.title || '',
    show: m.grandparentTitle || '',
    season: (m.parentIndex != null ? Number(m.parentIndex) : null),
    episode: (m.index != null && m.type === 'episode' ? Number(m.index) : null),
    year: m.year || (m.originallyAvailableAt ? String(m.originallyAvailableAt).slice(0, 4) : ''),
    summary: (m.summary || '').slice(0, 400),
    rating: m.rating || m.audienceRating || null,
    duration: m.duration || 0,
    viewedAt: m.viewedAt ? m.viewedAt * 1000 : null,
    art: thumb ? ('/api/plex/img?h=' + host + '&p=' + encodeURIComponent(thumb)) : '',
    absArt: /^https?:\/\//i.test(thumb)
  };
}
async function plexWatchlist (username, res) {
  const px = getUserPlex(username);
  if (!px || !px.token) return sendJSON(res, 400, { message: 'Not signed in to Plex' });
  // Plex Discover rejects large container sizes ("Invalid value provided for x-plex-container-size"),
  // so page through in small chunks instead of asking for everything at once.
  const PAGE = 20, MAX_PAGES = 15;
  const items = [];
  let last = null;
  for (let page = 0; page < MAX_PAGES; page++) {
    const url = PLEX_DISCOVER + '/library/sections/watchlist/all'
      + '?includeCollections=1&includeExternalMedia=1&includeAdvanced=1&includeMeta=1'
      + '&X-Plex-Container-Start=' + (page * PAGE) + '&X-Plex-Container-Size=' + PAGE;
    const r = await plexJson(url, px.token);
    if (!r.ok) {
      if (items.length) break;                      // partial results are still useful
      return sendJSON(res, 502, { message: plexErr(r, 'Plex watchlist unavailable') });
    }
    last = r.data;
    const batch = plexItemsFrom(r.data);
    items.push.apply(items, batch);
    const total = Number(((r.data || {}).MediaContainer || {}).totalSize || 0);
    if (batch.length < PAGE || (total && items.length >= total)) break;
  }
  sendJSON(res, 200, { items: items.map(m => plexCard(m, 'meta')), total: Number(((last || {}).MediaContainer || {}).totalSize || items.length) });
}
async function plexWatchlistAction (username, body, add, res) {
  const px = getUserPlex(username);
  if (!px || !px.token) return sendJSON(res, 400, { message: 'Not signed in to Plex' });
  let key = String(body.ratingKey || '').trim();
  if (!key) {
    const q = String(body.title || '').trim();
    if (!q) return sendJSON(res, 400, { message: 'Nothing to add' });
    const isShow = body.type === 'series' || body.type === 'show';
    const enc = encodeURIComponent(q);
    const types = isShow ? 'tv' : 'movies';
    // Shape taken from python-plexapi's searchDiscover(): searchProviders is required,
    // otherwise Discover answers 404 "Missing library search".
    const attempts = [
      PLEX_DISCOVER + '/library/search?query=' + enc + '&limit=10&searchTypes=' + types + '&searchProviders=discover&includeMetadata=1',
      PLEX_DISCOVER + '/library/search?query=' + enc + '&limit=10&searchTypes=movies,tv&searchProviders=discover&includeMetadata=1',
      PLEX_DISCOVER + '/library/search?query=' + enc + '&limit=10&searchTypes=movies,tv&searchProviders=discover,PLEXAVOD&includeMetadata=1'
    ];
    let results = [], lastErr = null;
    for (const url of attempts) {
      const s = await plexJson(url, px.token);
      if (!s.ok) { lastErr = s; continue; }
      const mc = (s.data || {}).MediaContainer || {};
      const groups = [].concat(mc.SearchResults || [], mc.SearchResult || []);
      // Prefer the "external" (Discover) group, then fall back to every group.
      const external = groups.filter(g => g && g.id === 'external');
      for (const g of (external.length ? external : groups)) {
        const hits = g.SearchResult || (g.Metadata ? [g] : []);
        for (const h of hits) if (h.Metadata) results.push(h.Metadata);
      }
      if (!results.length && Array.isArray(mc.Metadata)) results.push.apply(results, mc.Metadata);
      if (results.length) break;
    }
    if (!results.length) {
      if (lastErr) return sendJSON(res, 502, { message: plexErr(lastErr, 'Plex search failed') });
      return sendJSON(res, 404, { message: 'Not found on Plex' });
    }
    const wantType = isShow ? 'show' : 'movie';
    const yr = Number(body.year) || 0;
    const typed = results.filter(m => !m.type || m.type === wantType);
    const pool = typed.length ? typed : results;
    const hit = (yr && pool.find(m => Number(m.year) === yr)) || pool[0];
    key = plexActionKey(hit);
    if (!key) return sendJSON(res, 404, { message: 'Not found on Plex' });
  }
  const act = add ? 'addToWatchlist' : 'removeFromWatchlist';
  const r = await plexJson(PLEX_DISCOVER + '/actions/' + act + '?ratingKey=' + encodeURIComponent(key), px.token, 'PUT');
  if (!r.ok) return sendJSON(res, 502, { message: plexErr(r, 'Plex rejected the request') });
  sendJSON(res, 200, { ok: true, ratingKey: key, watchlisted: add });
}
// Map a Plex.tv account to its local account ID on the server (owner is normally 1).
async function plexServerAccountId (base, token, px) {
  if (px && px.accountId != null) return px.accountId;
  const names = [String((px && px.username) || '').toLowerCase()].filter(Boolean);
  for (const tok of [token, readConfig().plex.token].filter(Boolean)) {
    const r = await plexJson(base + '/accounts', tok);
    if (!r.ok) continue;
    const accounts = (((r.data || {}).MediaContainer || {}).Account) || [];
    let hit = accounts.find(a => names.includes(String(a.name || '').toLowerCase()));
    if (!hit && px && px.id) hit = accounts.find(a => String(a.id) === String(px.id));
    if (hit) return Number(hit.id);
  }
  return null;
}
async function plexHistory (username, limit, res) {
  const px = getUserPlex(username);
  if (!px || !px.token) return sendJSON(res, 400, { message: 'Not signed in to Plex' });
  const cfg = readConfig().plex;
  if (!cfg.url) return sendJSON(res, 400, { message: 'No Plex server is configured' });
  const base = normUrl(cfg.url);

  // Without an accountID the server returns EVERY user's history (obvious when you're the owner),
  // so resolve this user's account on the server and always scope the query to it.
  let acctId = await plexServerAccountId(base, px.token, px);
  if (acctId != null && px.accountId == null) { px.accountId = acctId; setUserPlex(username, px); }

  const q = '?sort=viewedAt:desc&X-Plex-Container-Start=0&X-Plex-Container-Size=' + limit
          + (acctId != null ? '&accountID=' + encodeURIComponent(acctId) : '');
  let r = await plexJson(base + '/status/sessions/history/all' + q, px.token);
  if (!r.ok && cfg.token) r = await plexJson(base + '/status/sessions/history/all' + q, cfg.token);
  if (!r.ok) return sendJSON(res, 502, { message: plexErr(r, 'Couldn’t read history from your Plex server') });
  const items = plexItemsFrom(r.data).map(m => plexCard(m, 'pms'));
  const movies = items.filter(i => i.type === 'movie');
  const eps = items.filter(i => i.type === 'episode');
  const shows = new Set(eps.map(e => e.show).filter(Boolean));
  const stats = {
    total: items.length, movies: movies.length, episodes: eps.length, shows: shows.size,
    firstAt: items.length ? items[items.length - 1].viewedAt : null,
    lastAt: items.length ? items[0].viewedAt : null,
    hours: Math.round(items.reduce((a, i) => a + (i.duration || 0), 0) / 3600000)
  };
  sendJSON(res, 200, { items, stats, scoped: acctId != null, account: (px.username || '') });
}
// Plex artwork can be a server-relative path OR an absolute URL (Discover returns absolute
// URLs on Plex/TMDB CDNs), so handle both — and fall back to the admin token for server art.
const IMG_HOSTS = ['plex.tv', 'plex.direct', 'image.tmdb.org', 'artworks.thetvdb.com', 'thetvdb.com'];
function imgHostAllowed (h) { h = String(h || '').toLowerCase(); return IMG_HOSTS.some(d => h === d || h.endsWith('.' + d)); }
/* Plex Home: an account can hold several profiles — let the user pick which one to use. */
async function plexHomeUsers (token) {
  for (const url of ['https://plex.tv/api/v2/home/users', 'https://plex.tv/api/home/users']) {
    const r = await plexJson(url, token);
    if (!r.ok) continue;
    const d = r.data || {};
    let raw = d.users || d.Users || (d.MediaContainer && d.MediaContainer.User) || [];
    // plex.tv often answers XML here: <home><users><user id uuid title .../></users></home>
    if ((!Array.isArray(raw) || !raw.length) && r.text && r.text.indexOf('<') === 0) raw = xmlAttrs(r.text, 'user');
    const list = (Array.isArray(raw) ? raw : []).map(u => ({
      id: u.id != null ? u.id : u.uuid, uuid: u.uuid || '',
      title: u.title || u.friendlyName || u.username || u.name || 'User',
      username: u.username || '',
      admin: String(u.admin) === '1' || u.admin === true || !!u.homeAdmin,
      restricted: String(u.restricted) === '1' || u.restricted === true,
      protected: String(u.protected) === '1' || u.protected === true,
      thumb: u.thumb || ''
    })).filter(u => u.id != null && u.id !== '');
    if (list.length) return { ok: true, users: list };
  }
  return { ok: false, users: [] };
}
async function plexSwitchHomeUser (token, id, uuid, pin) {
  const q = pin ? ('?pin=' + encodeURIComponent(pin)) : '';
  const ids = [id, uuid].filter(x => x != null && x !== '');
  const urls = [];
  for (const x of ids) {
    urls.push('https://plex.tv/api/home/users/' + encodeURIComponent(x) + '/switch' + q);       // v1 (what plexapi uses)
    urls.push('https://plex.tv/api/v2/home/users/' + encodeURIComponent(x) + '/switch' + q);
  }
  let lastErr = null;
  for (const url of urls) {
    const r = await plexJson(url, token, 'POST');
    if (!r.ok) { if (!lastErr || (r.status && !lastErr.status)) lastErr = r; continue; }
    const d = r.data || {};
    let tok = d.authToken || d.authenticationToken || (d.user && (d.user.authToken || d.user.authenticationToken));
    // XML: <user ... authenticationToken="..."/>
    if (!tok && r.text) {
      const el = xmlAttrs(r.text, 'user')[0] || xmlAttrs(r.text, 'User')[0];
      if (el) tok = el.authenticationToken || el.authToken;
    }
    if (tok) return { ok: true, token: tok };
    lastErr = { status: r.status || 200, message: 'no token in response' };
  }
  return { ok: false, err: lastErr };
}

async function plexImage (username, host, p, res) {
  const px = getUserPlex(username);
  const cfg = readConfig().plex;
  p = String(p || '');
  let target = null;
  const tokens = [];
  if (/^https?:\/\//i.test(p)) {
    let U; try { U = new URL(p); } catch (e) { res.writeHead(400); return res.end(); }
    let pmsHost = ''; try { pmsHost = new URL(normUrl(cfg.url || '')).hostname; } catch (e) {}
    if (!imgHostAllowed(U.hostname) && U.hostname !== pmsHost) { res.writeHead(403); return res.end(); }
    target = U.toString();
    if (px && px.token) tokens.push(px.token);
    if (cfg.token) tokens.push(cfg.token);
  } else {
    if (!p.startsWith('/') || p.indexOf('//') === 0) { res.writeHead(404); return res.end(); }
    const base = host === 'pms' ? normUrl(cfg.url || '') : PLEX_METADATA;
    if (!base) { res.writeHead(404); return res.end(); }
    target = base + p;
    if (px && px.token) tokens.push(px.token);
    if (host === 'pms' && cfg.token) tokens.push(cfg.token);
  }
  if (!tokens.length) { res.writeHead(404); return res.end(); }
  for (const tok of tokens) {
    try {
      const up = await upstream(target, { headers: { 'X-Plex-Token': tok, Accept: 'image/*' } });
      if (up.status < 400) {
        res.writeHead(200, { 'Content-Type': up.headers['content-type'] || 'image/jpeg', 'Cache-Control': 'private, max-age=86400' });
        return res.end(up.body);
      }
    } catch (e) { /* try the next token */ }
  }
  res.writeHead(404); res.end();
}
function wmode (m) { return m === 'proxy' ? 'proxy' : (m === 'embed' ? 'embed' : 'redirect'); }   // 'direct'/legacy/unknown -> redirect

/* ---------- helpers ---------- */
function readBody (req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', c => { d += c; if (d.length > 5e6) req.destroy(); });
    req.on('end', () => resolve(d));
    req.on('error', reject);
  });
}

// Make an upstream HTTP(S) request, return { status, headers, body(Buffer) }.
function upstream (targetUrl, { method = 'GET', headers = {}, body = null } = {}) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(targetUrl); } catch (e) { return reject(new Error('Invalid URL: ' + targetUrl)); }
    const lib = u.protocol === 'https:' ? https : http;
    const opts = {
      method,
      hostname: u.hostname,
      port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search,
      headers,
      timeout: 20000
    };
    const r = lib.request(opts, resp => {
      const chunks = [];
      resp.on('data', c => chunks.push(c));
      resp.on('end', () => resolve({ status: resp.statusCode, headers: resp.headers, body: Buffer.concat(chunks) }));
    });
    r.on('error', err => reject(err));
    r.on('timeout', () => r.destroy(new Error('Connection timed out')));
    if (body) r.write(body);
    r.end();
  });
}

function sendJSON (res, status, obj) {
  const s = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(s) });
  res.end(s);
}

const MIME = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.svg':'image/svg+xml', '.png':'image/png', '.ico':'image/x-icon' };
function serveStatic (res, file) {
  const full = path.join(PUBLIC_DIR, file);
  if (!full.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream' });
    res.end(data);
  });
}

// Serve a vendored asset (Bootstrap). If it's already cached in /public, serve that (works fully
// offline). Otherwise fetch it once from the CDN, cache it to /public for next time, and serve it.
async function serveVendor (res, name, url) {
  const cachePath = path.join(PUBLIC_DIR, name);
  const ctype = name.endsWith('.css') ? 'text/css' : 'text/javascript';
  try {
    if (fs.existsSync(cachePath)) {
      const buf = fs.readFileSync(cachePath);
      res.writeHead(200, { 'Content-Type': ctype, 'Content-Length': buf.length, 'Cache-Control': 'public, max-age=86400' });
      return res.end(buf);
    }
  } catch (e) {}
  try {
    let up = await upstream(url, { headers: { 'Accept': '*/*', 'User-Agent': 'mediarr' } });
    let hops = 0;
    while (up.status >= 300 && up.status < 400 && up.headers.location && hops++ < 3) {
      up = await upstream(up.headers.location, { headers: { 'Accept': '*/*', 'User-Agent': 'mediarr' } });
    }
    if (up.status !== 200) throw new Error('CDN returned HTTP ' + up.status);
    try { fs.writeFileSync(cachePath, up.body); } catch (e) {}   // cache for offline next time
    res.writeHead(200, { 'Content-Type': ctype, 'Content-Length': up.body.length, 'Cache-Control': 'public, max-age=86400' });
    return res.end(up.body);
  } catch (e) {
    res.writeHead(502, { 'Content-Type': 'text/plain' });
    return res.end('Could not load ' + name + ': ' + e.message + '. The mobile UI needs internet on first load to cache Bootstrap, or you can drop the file into /public manually.');
  }
}
function readUsers () { try { return JSON.parse(fs.readFileSync(USERS_PATH, 'utf8')); } catch (e) { return { users: [] }; } }
function writeUsers (u) { fs.writeFileSync(USERS_PATH, JSON.stringify(u, null, 2)); }
function findUser (username) { return readUsers().users.find(u => u.username.toLowerCase() === String(username || '').toLowerCase()); }

/* ---------- per-user theme + personal API key ---------- */
const THEME_VARS = ['bg', 'bg2', 'panel', 'panel2', 'line', 'txt', 'muted', 'gold', 'gold-dim', 'radarr', 'sonarr', 'green', 'red'];
function cleanColor (v) {
  v = String(v == null ? '' : v).trim();
  if (!v) return '';
  if (/^#[0-9a-f]{3}$/i.test(v) || /^#[0-9a-f]{6}$/i.test(v) || /^#[0-9a-f]{8}$/i.test(v)) return v;
  if (/^rgba?\(\s*[\d.]+\s*,\s*[\d.]+\s*,\s*[\d.]+\s*(,\s*[\d.]+\s*)?\)$/i.test(v)) return v;
  if (/^hsla?\(\s*[\d.]+\s*,\s*[\d.]+%\s*,\s*[\d.]+%\s*(,\s*[\d.]+\s*)?\)$/i.test(v)) return v;
  return '';
}
function sanitizeTheme (t) {
  const out = { base: (t && t.base === 'light') ? 'light' : 'dark', modes: { dark: {}, light: {} } };
  const src = (t && t.modes) || {};
  for (const mode of ['dark', 'light']) {
    const m = src[mode] || {};
    for (const k of THEME_VARS) { const c = cleanColor(m[k]); if (c) out.modes[mode][k] = c; }
  }
  // migrate the older single-palette shape into whichever base it was saved under
  if (t && t.vars && !t.modes) {
    for (const k of THEME_VARS) { const c = cleanColor(t.vars[k]); if (c) out.modes[out.base][k] = c; }
  }
  return out;
}
function userTheme (username) { const u = findUser(username); return (u && u.theme) ? sanitizeTheme(u.theme) : { base: 'dark', modes: { dark: {}, light: {} } }; }
function setUserField (username, field, value) {
  const data = readUsers();
  const u = data.users.find(x => x.username.toLowerCase() === String(username).toLowerCase());
  if (!u) return false;
  if (value == null) delete u[field]; else u[field] = value;
  writeUsers(data); return true;
}
function newApiKey () { return 'mk_' + crypto.randomBytes(24).toString('hex'); }
function findUserByApiKey (key) {
  key = String(key || '').trim();
  if (!key || key.length < 8) return null;
  return readUsers().users.find(u => u.apiKey && crypto.timingSafeEqual(
    Buffer.from(String(u.apiKey).padEnd(80, '\0').slice(0, 80)),
    Buffer.from(key.padEnd(80, '\0').slice(0, 80)))) || null;
}
function apiKeyFromReq (req, u) {
  return String(req.headers['x-api-key'] || u.searchParams.get('api_key') || '').trim();
}
function hashPassword (password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function verifyPassword (password, salt, hash) {
  const h = crypto.scryptSync(String(password), salt, 64).toString('hex');
  const a = Buffer.from(h), b = Buffer.from(hash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const sessions = new Map();   // token -> { username, expires }
function parseCookies (req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}
function currentUser (req) {
  const tok = parseCookies(req).mediarr_session;
  if (!tok) return null;
  const s = sessions.get(tok);
  if (!s || s.expires < Date.now()) { if (s) sessions.delete(tok); return null; }
  const u = findUser(s.username);
  if (!u) { sessions.delete(tok); return null; }
  return u;
}
// Is this request effectively HTTPS? Behind Caddy/nginx the TLS terminates at the proxy,
// which tells us via X-Forwarded-Proto. SECURE_COOKIES=1 forces it on regardless.
function isSecureRequest (req) {
  if (process.env.SECURE_COOKIES === '1') return true;
  const xfp = (req.headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
  if (xfp) return xfp === 'https';
  return !!(req.socket && req.socket.encrypted);
}
function createSession (req, res, username) {
  const tok = crypto.randomBytes(32).toString('hex');
  sessions.set(tok, { username, expires: Date.now() + SESSION_MS });
  const secure = isSecureRequest(req) ? ' Secure;' : '';   // only over HTTPS, so local HTTP still works
  res.setHeader('Set-Cookie', `mediarr_session=${tok}; HttpOnly;${secure} SameSite=Lax; Path=/; Max-Age=${Math.floor(SESSION_MS/1000)}`);
}
function clearSession (req, res) {
  const tok = parseCookies(req).mediarr_session;
  if (tok) sessions.delete(tok);
  const secure = isSecureRequest(req) ? ' Secure;' : '';
  res.setHeader('Set-Cookie', `mediarr_session=; HttpOnly;${secure} SameSite=Lax; Path=/; Max-Age=0`);
}
function publicUser (u, withCounts) {
  const o = { username: u.username, role: u.role, dailyLimit: u.dailyLimit, createdAt: u.createdAt };
  if (withCounts) o.addedToday = addsTodayCount(u.username);
  return o;
}

/* ---------- add log (what each user added) ---------- */
function readAdds () { try { return JSON.parse(fs.readFileSync(ADDS_PATH, 'utf8')); } catch (e) { return { adds: [] }; } }
function writeAdds (a) { fs.writeFileSync(ADDS_PATH, JSON.stringify(a, null, 2)); }
function logAdd (entry) { const a = readAdds(); a.adds.unshift(entry); if (a.adds.length > MAX_ADDS_LOG) a.adds.length = MAX_ADDS_LOG; writeAdds(a); }

/* ---------- favorite TV shows (per user) ---------- */
function readFavs () { try { return JSON.parse(fs.readFileSync(FAVS_PATH, 'utf8')); } catch (e) { return { users: {} }; } }
function writeFavs (f) { fs.writeFileSync(FAVS_PATH, JSON.stringify(f, null, 2)); }
function favKey (it) {
  if (it.imdbId) return 'imdb:' + String(it.imdbId).toLowerCase();
  if (it.tvdbId) return 'tvdb:' + it.tvdbId;
  if (it.tmdbId) return 'tmdb:' + it.tmdbId;
  return 'name:' + String(it.title || '').trim().toLowerCase();
}
function userFavs (username) { const f = readFavs(); return (f.users && f.users[username]) || []; }
function normTitle (s) { return String(s || '').toLowerCase().replace(/\(\d{4}\)/g, '').replace(/[^a-z0-9]+/g, ' ').trim(); }

// Server-side JSON GET against Radarr/Sonarr (returns null instead of throwing).
async function arrJson (svc, subPath) {
  const cfg = readConfig()[svc];
  if (!cfg.url || !cfg.apiKey) return null;
  try {
    const up = await upstream(normUrl(cfg.url) + subPath, { headers: { 'X-Api-Key': cfg.apiKey, 'Accept': 'application/json' } });
    if (up.status >= 400) return null;
    return JSON.parse(up.body.toString('utf8'));
  } catch (e) { return null; }
}
async function tmdbJson (subPath) {
  const key = readConfig().tmdb.apiKey;
  if (!key) return null;
  try {
    const sep = subPath.includes('?') ? '&' : '?';
    const up = await upstream(TMDB + subPath + sep + 'api_key=' + encodeURIComponent(key), { headers: { Accept: 'application/json' } });
    if (up.status >= 400) return null;
    return JSON.parse(up.body.toString('utf8'));
  } catch (e) { return null; }
}

/* Watched-episode index from Plex, cached briefly (one pass over TV sections). */
let _plexWatched = { ts: 0, set: null, shows: null };
async function plexWatchedIndex () {
  const now = Date.now();
  if (_plexWatched.set && (now - _plexWatched.ts) < 60000) return _plexWatched;
  const cfg = readConfig().plex;
  if (!cfg.url || !cfg.token) return { ts: now, set: new Set(), shows: new Map() };
  const base = normUrl(cfg.url), headers = { 'X-Plex-Token': cfg.token, Accept: 'application/json' };
  const set = new Set(), shows = new Map();
  try {
    const list = await upstream(base + '/library/sections', { headers });
    let dirs = [];
    try { dirs = (JSON.parse(list.body.toString('utf8')).MediaContainer || {}).Directory || []; } catch (e) {}
    for (const d of dirs.filter(x => x.type === 'show')) {
      try {
        const ep = await upstream(base + '/library/sections/' + encodeURIComponent(d.key) + '/all?type=4', { headers });
        let metas = [];
        try { metas = (JSON.parse(ep.body.toString('utf8')).MediaContainer || {}).Metadata || []; } catch (e) {}
        for (const m of metas) {
          if (!(m.viewCount > 0)) continue;
          const show = normTitle(m.grandparentTitle), s = Number(m.parentIndex), e = Number(m.index);
          if (!show || !Number.isFinite(s) || !Number.isFinite(e)) continue;
          set.add(show + '|' + s + '|' + e);
          const cur = shows.get(show);
          if (!cur || s > cur.season || (s === cur.season && e > cur.episode)) shows.set(show, { season: s, episode: e });
        }
      } catch (e) { /* skip a section that fails */ }
    }
  } catch (e) { /* Plex unreachable — return what we have */ }
  _plexWatched = { ts: now, set, shows };
  return _plexWatched;
}

/* Next upcoming episode for each of a user's favorite shows. */
async function favoritesUpcoming (username, res) {
  const favs = userFavs(username);
  if (!favs.length) return sendJSON(res, 200, { items: [], favorites: 0 });
  const series = (await arrJson('sonarr', '/api/v3/series')) || [];
  const watched = await plexWatchedIndex();
  const now = Date.now();
  const items = [];
  for (const f of favs) {
    let next = null, prev = null, poster = f.poster || '';
    const match = series.find(s =>
      (f.tvdbId && s.tvdbId === Number(f.tvdbId)) ||
      (f.imdbId && s.imdbId && String(s.imdbId).toLowerCase() === String(f.imdbId).toLowerCase()) ||
      normTitle(s.title) === normTitle(f.title));
    if (match) {
      const eps = (await arrJson('sonarr', '/api/v3/episode?seriesId=' + match.id)) || [];
      const dated = eps.filter(e => e.airDateUtc && e.seasonNumber > 0);
      const future = dated.filter(e => new Date(e.airDateUtc).getTime() > now).sort((a, b) => new Date(a.airDateUtc) - new Date(b.airDateUtc));
      const past = dated.filter(e => new Date(e.airDateUtc).getTime() <= now).sort((a, b) => new Date(b.airDateUtc) - new Date(a.airDateUtc));
      if (future[0]) next = { season: future[0].seasonNumber, episode: future[0].episodeNumber, name: future[0].title || '', airDate: future[0].airDateUtc };
      if (past[0])   prev = { season: past[0].seasonNumber, episode: past[0].episodeNumber, name: past[0].title || '', airDate: past[0].airDateUtc };
    } else if (f.tmdbId) {
      const tv = await tmdbJson('/tv/' + f.tmdbId);
      if (tv) {
        if (tv.next_episode_to_air) next = { season: tv.next_episode_to_air.season_number, episode: tv.next_episode_to_air.episode_number, name: tv.next_episode_to_air.name || '', airDate: tv.next_episode_to_air.air_date };
        if (tv.last_episode_to_air) prev = { season: tv.last_episode_to_air.season_number, episode: tv.last_episode_to_air.episode_number, name: tv.last_episode_to_air.name || '', airDate: tv.last_episode_to_air.air_date };
      }
    }
    const key = normTitle(f.title);
    const seenPrev = !!(prev && watched.set.has(key + '|' + prev.season + '|' + prev.episode));
    items.push({ key: f.key, title: f.title, poster, tvdbId: f.tvdbId || null, imdbId: f.imdbId || '', tmdbId: f.tmdbId || null,
      next, prev, watchedPrev: seenPrev, inSonarr: !!match });
  }
  items.sort((a, b) => {
    if (a.next && b.next) return new Date(a.next.airDate) - new Date(b.next.airDate);
    if (a.next) return -1; if (b.next) return 1;
    return String(a.title).localeCompare(String(b.title));
  });
  sendJSON(res, 200, { items, favorites: favs.length });
}
function startOfToday () { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); }
// Count only limit-relevant actions (adds + downloads) toward the daily limit — never plays.
function addsTodayCount (username) { const t = startOfToday(); return readAdds().adds.filter(e => e.username === username && e.ts >= t && e.type !== 'play').length; }

// Best-effort client IP. Behind Caddy/nginx the real client is in X-Forwarded-For (first hop);
// otherwise fall back to the socket address. Strips the IPv4-in-IPv6 "::ffff:" prefix.
function clientIp (req) {
  const xff = (req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  let ip = xff || (req.socket && req.socket.remoteAddress) || '';
  if (ip.indexOf('::ffff:') === 0) ip = ip.slice(7);
  return ip;
}
// A single media play triggers many range/segment requests, so throttle to one log entry
// per user+file per 60s (re-watching later logs a fresh play, which is fine for monitoring).
const recentPlays = new Map();
function logPlayOnce (user, rel, req) {
  if (!user) return;
  const key = user.username + '|' + rel, now = Date.now();
  if (now - (recentPlays.get(key) || 0) < 60000) return;
  recentPlays.set(key, now);
  if (recentPlays.size > 500) { for (const [k, t] of recentPlays) if (now - t > 120000) recentPlays.delete(k); }
  logAdd({ ts: now, username: user.username, role: user.role, service: 'webdav', type: 'play', title: (rel || '').split('/').pop(), year: '', ip: clientIp(req) });
}

/* ---------- arr connection test (uses typed creds, falls back to stored) ---------- */
async function testService (svc, url, key) {
  const stored = readConfig()[svc];
  const base = normUrl(url || stored.url);
  const apiKey = key || stored.apiKey;
  if (!base || !apiKey) throw new Error('Missing URL or API key');
  const headers = { 'X-Api-Key': apiKey };

  const status  = await upstream(base + '/api/v3/system/status', { headers });
  if (status.status === 401) throw new Error('Unauthorized — check the API key');
  if (status.status >= 400)  throw new Error('Server returned HTTP ' + status.status);
  const sys = JSON.parse(status.body.toString() || '{}');

  const prof = await upstream(base + '/api/v3/qualityprofile', { headers });
  const fold = await upstream(base + '/api/v3/rootfolder', { headers });
  const profiles = JSON.parse(prof.body.toString() || '[]');
  const folders  = JSON.parse(fold.body.toString() || '[]');

  return {
    name: sys.instanceName || sys.appName || svc,
    version: sys.version || '',
    profiles: profiles.map(p => ({ id: p.id, name: p.name })),
    folders:  folders.map(f => ({ path: f.path, freeSpace: f.freeSpace || 0 }))
  };
}

async function testTmdb (key) {
  const stored = readConfig().tmdb;
  const useKey = key || stored.apiKey;
  if (!useKey) throw new Error('Missing API key');
  const r = await upstream(TMDB + '/configuration?api_key=' + encodeURIComponent(useKey));
  if (r.status === 401) throw new Error('Invalid TMDB API key');
  if (r.status >= 400)  throw new Error('TMDB returned HTTP ' + r.status);
  return { name: 'TMDB', version: '' };
}

async function testPlex (url, token) {
  const stored = readConfig().plex;
  const base = normUrl(url || stored.url);
  const tok = token || stored.token;
  if (!base || !tok) throw new Error('Missing URL or token');
  const r = await upstream(base + '/identity', { headers: { 'X-Plex-Token': tok, 'Accept': 'application/json' } });
  if (r.status === 401) throw new Error('Unauthorized — check the Plex token');
  if (r.status >= 400)  throw new Error('Plex returned HTTP ' + r.status);
  let mc = {};
  try { mc = (JSON.parse(r.body.toString() || '{}').MediaContainer) || {}; } catch (e) {}
  return { name: 'Plex', version: mc.version || '' };
}

// Privacy: only first 4 chars of the username, and never expose IP / addresses.
function maskUser (name) {
  const n = String(name || '').trim();
  if (!n) return 'User';
  return n.slice(0, 4) + (n.length > 4 ? '…' : '');
}
function sanitizeSession (s) {
  const player = s.Player || {};
  const user = s.User || {};
  const out = {
    type: s.type,
    user: maskUser(user.title || (user.id != null ? 'id' + user.id : '')),
    state: player.state || '',
    device: player.product || player.title || player.platform || '',   // NOT player.address
    progress: (s.duration ? Math.min(100, Math.max(0, Math.round((Number(s.viewOffset || 0) / Number(s.duration)) * 100))) : null)
  };
  if (s.type === 'episode') {
    out.show = s.grandparentTitle || '';
    out.season = (s.parentIndex != null ? s.parentIndex : null);
    out.episode = (s.index != null ? s.index : null);
    out.episodeTitle = s.title || '';
  } else if (s.type === 'movie') {
    out.title = s.title || '';
    out.year = s.year || '';
  } else {
    out.title = s.title || s.grandparentTitle || '';
    out.subtitle = s.parentTitle || s.grandparentTitle || '';
  }
  return out;
}
async function plexSessions () {
  const cfg = readConfig().plex;
  if (!cfg.url || !cfg.token) return { configured: false, count: 0, sessions: [] };
  try {
    const up = await upstream(normUrl(cfg.url) + '/status/sessions', { headers: { 'X-Plex-Token': cfg.token, 'Accept': 'application/json' } });
    if (up.status >= 400) return { configured: true, error: 'Plex HTTP ' + up.status, count: 0, sessions: [] };
    let mc = {};
    try { mc = (JSON.parse(up.body.toString() || '{}').MediaContainer) || {}; } catch (e) {}
    const sessions = (mc.Metadata || []).map(sanitizeSession);
    return { configured: true, count: sessions.length, sessions };
  } catch (e) {
    return { configured: true, error: e.message, count: 0, sessions: [] };
  }
}

/* ---------- health monitoring (background) ---------- */
let healthState = (function () {
  try { return JSON.parse(fs.readFileSync(HEALTH_PATH, 'utf8')); }
  catch (e) { return { services: {}, events: [] }; }
})();
function saveHealth () { try { fs.writeFileSync(HEALTH_PATH, JSON.stringify(healthState, null, 2)); } catch (e) {} }

function monitoredTargets () {
  const c = readConfig(); const t = [];
  if (c.plex.url && c.plex.token)     t.push({ name: 'plex',   url: normUrl(c.plex.url) + '/identity',          headers: { 'X-Plex-Token': c.plex.token, 'Accept': 'application/json' } });
  if (c.radarr.url && c.radarr.apiKey) t.push({ name: 'radarr', url: normUrl(c.radarr.url) + '/api/v3/system/status', headers: { 'X-Api-Key': c.radarr.apiKey } });
  if (c.sonarr.url && c.sonarr.apiKey) t.push({ name: 'sonarr', url: normUrl(c.sonarr.url) + '/api/v3/system/status', headers: { 'X-Api-Key': c.sonarr.apiKey } });
  return t;
}
function recordStatus (name, up, meta) {
  const now = Date.now();
  const prev = healthState.services[name] || null;
  const prevUp = prev ? prev.up : null;
  if (prevUp !== up) {
    if (up === false) {
      healthState.events.unshift({ service: name, downAt: now, upAt: null });
      if (healthState.events.length > MAX_EVENTS) healthState.events.length = MAX_EVENTS;
    } else if (up === true && prevUp === false) {
      const ev = healthState.events.find(e => e.service === name && e.upAt === null);
      if (ev) { ev.upAt = now; ev.durationMs = now - ev.downAt; }
    }
  }
  healthState.services[name] = {
    up,
    since: (prevUp === up && prev) ? prev.since : now,
    lastChecked: now,
    version: meta.version || (prev && prev.version) || '',
    responseMs: meta.responseMs,
    error: meta.error || ''
  };
  saveHealth();
}
async function checkOne (t) {
  const start = Date.now();
  let up = false, version = '', error = '';
  try {
    const r = await upstream(t.url, { headers: t.headers });
    if (r.status >= 200 && r.status < 400) {
      up = true;
      try { const j = JSON.parse(r.body.toString() || '{}'); version = j.version || (j.MediaContainer || {}).version || ''; } catch (e) {}
    } else { error = 'HTTP ' + r.status; }
  } catch (e) { error = e.message; }
  recordStatus(t.name, up, { version, responseMs: Date.now() - start, error });
}
async function runAllChecks () {
  const targets = monitoredTargets();
  // drop state for services no longer configured
  for (const k of Object.keys(healthState.services)) if (!targets.find(t => t.name === k)) delete healthState.services[k];
  await Promise.all(targets.map(checkOne));
}

/* ---------- proxy a request to an arr server or cinemeta ---------- */
async function proxyArr (svc, subPath, req, res) {
  const cfg = readConfig()[svc];
  if (!cfg.url || !cfg.apiKey) return sendJSON(res, 400, { message: svc + ' is not configured yet' });
  const body = ['POST', 'PUT', 'DELETE'].includes(req.method) ? await readBody(req) : null;

  // An "add" is a POST to the movie/series collection endpoint.
  const cleanPath = subPath.split('?')[0];
  const isAdd = req.method === 'POST' &&
    ((svc === 'radarr' && cleanPath === '/api/v3/movie') || (svc === 'sonarr' && cleanPath === '/api/v3/series'));

  const user = currentUser(req);
  // Regular users may only read (GET) and add (POST to the collection). No edits, monitor changes, commands, or deletes.
  if (user && user.role !== 'admin' && req.method !== 'GET' && !isAdd) {
    return sendJSON(res, 403, { message: 'Editing library options and monitoring is restricted to admins.' });
  }
  if (isAdd && user && user.role !== 'admin' && user.dailyLimit > 0) {
    const used = addsTodayCount(user.username);
    if (used >= user.dailyLimit) {
      return sendJSON(res, 429, { message: `Daily add limit reached (${used}/${user.dailyLimit}). Ask an admin to raise it or try again tomorrow.` });
    }
  }

  const target = normUrl(cfg.url) + subPath;
  try {
    const up = await upstream(target, {
      method: req.method,
      headers: { 'X-Api-Key': cfg.apiKey, 'Content-Type': 'application/json' },
      body
    });
    // log + count only successful adds
    if (isAdd && up.status >= 200 && up.status < 300 && user) {
      let title = '', year = '';
      try { const b = JSON.parse(body || '{}'); title = b.title || ''; year = b.year || ''; } catch (e) {}
      logAdd({ ts: Date.now(), username: user.username, role: user.role, service: svc, type: svc === 'radarr' ? 'movie' : 'series', title, year, ip: clientIp(req) });
    }
    res.writeHead(up.status, { 'Content-Type': up.headers['content-type'] || 'application/json' });
    res.end(up.body);
  } catch (e) {
    sendJSON(res, 502, { message: 'Could not reach ' + svc + ': ' + e.message });
  }
}
async function proxyCinemeta (subPath, res) {
  try {
    const up = await upstream(CINEMETA + subPath, { headers: { 'Accept': 'application/json' } });
    res.writeHead(up.status, { 'Content-Type': 'application/json' });
    res.end(up.body);
  } catch (e) {
    sendJSON(res, 502, { message: 'Cinemeta error: ' + e.message });
  }
}
async function proxyTmdb (subPath, res) {
  const key = readConfig().tmdb.apiKey;
  if (!key) return sendJSON(res, 400, { message: 'TMDB is not configured yet' });
  const sep = subPath.includes('?') ? '&' : '?';
  const target = TMDB + subPath + sep + 'api_key=' + encodeURIComponent(key);
  try {
    const up = await upstream(target, { headers: { 'Accept': 'application/json' } });
    res.writeHead(up.status, { 'Content-Type': 'application/json' });
    res.end(up.body);
  } catch (e) {
    sendJSON(res, 502, { message: 'TMDB error: ' + e.message });
  }
}
async function plexScan (res) {
  const cfg = readConfig().plex;
  if (!cfg.url || !cfg.token) return sendJSON(res, 400, { message: 'Plex is not configured yet' });
  const base = normUrl(cfg.url);
  const headers = { 'X-Plex-Token': cfg.token, 'Accept': 'application/json' };
  try {
    const list = await upstream(base + '/library/sections', { headers });
    if (list.status === 401) return sendJSON(res, 502, { message: 'Unauthorized — check the Plex token' });
    if (list.status >= 400) return sendJSON(res, 502, { message: 'Plex returned HTTP ' + list.status });
    let dirs = [];
    try { dirs = (JSON.parse(list.body.toString('utf8')).MediaContainer || {}).Directory || []; } catch (e) {}
    if (!dirs.length) return sendJSON(res, 200, { scanned: 0, sections: [], message: 'No Plex libraries found to scan.' });
    const sections = [];
    for (const d of dirs) {
      try { await upstream(base + '/library/sections/' + encodeURIComponent(d.key) + '/refresh', { headers }); sections.push(d.title || ('Section ' + d.key)); }
      catch (e) { /* skip a single failed section, keep going */ }
    }
    return sendJSON(res, 200, { scanned: sections.length, sections });
  } catch (e) {
    return sendJSON(res, 502, { message: 'Could not reach Plex: ' + e.message });
  }
}

async function proxyPlex (subPath, res) {
  const cfg = readConfig().plex;
  if (!cfg.url || !cfg.token) return sendJSON(res, 400, { message: 'Plex is not configured yet' });
  const target = normUrl(cfg.url) + subPath;
  try {
    const up = await upstream(target, { headers: { 'X-Plex-Token': cfg.token, 'Accept': 'application/json' } });
    res.writeHead(up.status, { 'Content-Type': up.headers['content-type'] || 'application/json' });
    res.end(up.body);
  } catch (e) {
    sendJSON(res, 502, { message: 'Could not reach Plex: ' + e.message });
  }
}

/* ---------- WebDAV (browse a folder, download files against the daily limit) ---------- */
const VIDEO_EXT = ['mkv','mp4','avi','mov','m4v','wmv','flv','webm','mpg','mpeg','ts','m2ts','vob','ogv','3gp','divx','mts'];
function webdavAuthHeader (cfg) { return 'Basic ' + Buffer.from((cfg.username || '') + ':' + (cfg.password || '')).toString('base64'); }
function encodePath (p) { return p.split('/').map(s => encodeURIComponent(s)).join('/'); }
// turn a user-supplied relative path into safe segments (no traversal)
function safeSegments (rel) {
  return String(rel || '').split('/').map(s => s.trim()).filter(s => s && s !== '.' && s !== '..');
}
function webdavTarget (cfg, rel) {
  const base = normUrl(cfg.url);
  const folderSegs = safeSegments(cfg.folder);
  const relSegs = safeSegments(rel);
  const all = folderSegs.concat(relSegs);
  return base + (all.length ? '/' + encodePath(all.join('/')) : '/');
}
function parsePropfind (xml) {
  const out = [];
  const blocks = xml.match(/<(?:\w+:)?response[\s>][\s\S]*?<\/(?:\w+:)?response>/gi) || [];
  for (const b of blocks) {
    const hrefM = b.match(/<(?:\w+:)?href[^>]*>([\s\S]*?)<\/(?:\w+:)?href>/i);
    if (!hrefM) continue;
    let href = hrefM[1].trim();
    let pathname = href;
    try { pathname = new URL(href, 'http://x').pathname; } catch (e) {}
    let decoded; try { decoded = decodeURIComponent(pathname); } catch (e) { decoded = pathname; }
    const isDir = /<(?:\w+:)?collection\b/i.test(b);
    const name = decoded.replace(/\/+$/, '').split('/').pop() || '';
    const lenM = b.match(/<(?:\w+:)?getcontentlength[^>]*>(\d+)<\/(?:\w+:)?getcontentlength>/i);
    const ctM  = b.match(/<(?:\w+:)?getcontenttype[^>]*>([\s\S]*?)<\/(?:\w+:)?getcontenttype>/i);
    out.push({ name, isDir, path: decoded.replace(/\/+$/, ''), size: lenM ? Number(lenM[1]) : 0, ctype: ctM ? ctM[1].trim() : '' });
  }
  return out;
}
async function webdavList (rel, res) {
  const cfg = readConfig().webdav;
  if (!cfg.url || !cfg.username) return sendJSON(res, 400, { message: 'WebDAV is not configured yet' });
  const target = webdavTarget(cfg, rel);
  try {
    const up = await upstream(target.endsWith('/') ? target : target + '/', {
      method: 'PROPFIND',
      headers: { Authorization: webdavAuthHeader(cfg), Depth: '1', 'Content-Type': 'application/xml', Accept: 'application/xml' }
    });
    if (up.status === 401) return sendJSON(res, 502, { message: 'WebDAV unauthorized — check username/password' });
    if (up.status === 404) return sendJSON(res, 502, { message: 'Folder not found on the WebDAV server' });
    if (up.status >= 400)  return sendJSON(res, 502, { message: 'WebDAV returned HTTP ' + up.status });
    let entries = parsePropfind(up.body.toString('utf8'));
    // drop the folder itself (the depth-0 self entry) — it's the one whose name matches the last requested segment or is empty
    const reqSegs = safeSegments(readConfig().webdav.folder).concat(safeSegments(rel));
    const selfName = reqSegs.length ? reqSegs[reqSegs.length - 1] : '';
    let seenSelf = false;
    entries = entries.filter(e => { if (!seenSelf && (e.name === selfName || e.name === '')) { seenSelf = true; return false; } return true; });
    const folders = entries.filter(e => e.isDir).map(e => ({ name: e.name }));
    const isVideo = e => VIDEO_EXT.includes((e.name.split('.').pop() || '').toLowerCase()) || /^video\//i.test(e.ctype);
    const files = entries.filter(e => !e.isDir && isVideo(e)).map(e => ({ name: e.name, size: e.size }));
    folders.sort((a, b) => a.name.localeCompare(b.name));
    files.sort((a, b) => a.name.localeCompare(b.name));
    return sendJSON(res, 200, { path: safeSegments(rel).join('/'), folders, files });
  } catch (e) {
    return sendJSON(res, 502, { message: 'Could not reach WebDAV: ' + e.message });
  }
}
// stream a file from WebDAV to the browser as a download
function webdavDownload (rel, res, user, isHead, req) {
  const cfg = readConfig().webdav;
  if (!cfg.url || !cfg.username) { res.writeHead(400); return res.end('WebDAV is not configured'); }
  const segs = safeSegments(rel);
  if (!segs.length) { res.writeHead(400); return res.end('No file specified'); }
  // enforce per-user daily limit (admins / dailyLimit 0 are unlimited)
  if (user && user.role !== 'admin' && user.dailyLimit > 0) {
    const used = addsTodayCount(user.username);
    if (used >= user.dailyLimit) { res.writeHead(429, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ message: `Daily limit reached (${used}/${user.dailyLimit}). Ask an admin to raise it or try again tomorrow.` })); }
  }
  const filename = segs[segs.length - 1];
  if (isHead) { res.writeHead(200); return res.end(); }   // preflight: quota ok
  const mode = wmode(cfg.mode);

  // REDIRECT / EMBED: count it, then send the browser straight to the WebDAV server (MEDIARR never relays the bytes).
  if (mode !== 'proxy') {
    let loc;
    try {
      const du = new URL(webdavTarget(cfg, rel));
      if (mode === 'embed' && cfg.username) { du.username = encodeURIComponent(cfg.username); du.password = encodeURIComponent(cfg.password || ''); }
      // mode 'redirect': no credentials in the URL — the browser authenticates to WebDAV itself (native login prompt, cached per session)
      loc = du.toString();
    } catch (e) { res.writeHead(400); return res.end('Bad path'); }
    if (user) logAdd({ ts: Date.now(), username: user.username, role: user.role, service: 'webdav', type: 'download', title: filename, year: '', ip: clientIp(req) });
    res.writeHead(302, { Location: loc, 'Cache-Control': 'no-store' });
    return res.end();
  }

  // PROXY mode: stream the file through MEDIARR.
  const target = webdavTarget(cfg, rel);
  let u; try { u = new URL(target); } catch (e) { res.writeHead(400); return res.end('Bad path'); }
  const lib = u.protocol === 'https:' ? https : http;
  const rq = lib.request({ method: 'GET', hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80), path: u.pathname + u.search, headers: { Authorization: webdavAuthHeader(cfg) }, timeout: 30000 }, up => {
    if (up.statusCode >= 400) { up.resume(); res.writeHead(502, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ message: 'WebDAV returned HTTP ' + up.statusCode })); }
    // count this download against the user's daily total
    if (user) logAdd({ ts: Date.now(), username: user.username, role: user.role, service: 'webdav', type: 'download', title: filename, year: '', ip: clientIp(req) });
    const h = { 'Content-Type': up.headers['content-type'] || 'application/octet-stream', 'Content-Disposition': 'attachment; filename="' + filename.replace(/[\r\n"]/g, '') + '"' };
    if (up.headers['content-length']) h['Content-Length'] = up.headers['content-length'];
    res.writeHead(200, h);
    up.pipe(res);
  });
  rq.on('error', err => { if (!res.headersSent) { res.writeHead(502, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'WebDAV error: ' + err.message })); } else { res.end(); } });
  rq.on('timeout', () => rq.destroy(new Error('Connection timed out')));
  rq.end();
}
const VIDEO_MIME = { mp4:'video/mp4', m4v:'video/mp4', webm:'video/webm', ogv:'video/ogg', mov:'video/quicktime', mkv:'video/x-matroska', avi:'video/x-msvideo', ts:'video/mp2t', m2ts:'video/mp2t', mpg:'video/mpeg', mpeg:'video/mpeg', wmv:'video/x-ms-wmv', flv:'video/x-flv', '3gp':'video/3gpp' };
// Stream a video for in-browser playback. Always proxies (so the <video> element is authenticated)
// and forwards Range requests so seeking works. Does NOT count against the daily limit (it's a preview, not a kept download).
function webdavStream (rel, req, res) {
  const cfg = readConfig().webdav;
  if (!cfg.url || !cfg.username) { res.writeHead(400); return res.end('WebDAV is not configured'); }
  const segs = safeSegments(rel);
  if (!segs.length) { res.writeHead(400); return res.end('No file specified'); }
  const name = segs[segs.length - 1];
  if (!req.headers.range || /^bytes=0-/.test(req.headers.range)) logPlayOnce(currentUser(req), rel, req);   // log at playback start, not every seek
  let q = {}; try { q = new URL(req.url, 'http://x').searchParams; } catch (e) { q = new URLSearchParams(); }
  const aidx = q.get('aidx');
  const wantTranscode = (q.get('transcode') === '1') || (q.get('vc') === '1') || (aidx != null && aidx !== '') || cfg.transcode;
  if (wantTranscode && FFMPEG) return webdavTranscode(cfg, rel, name, { ac: q.get('ac'), vc: q.get('vc'), aidx }, req, res);
  let u; try { u = new URL(webdavTarget(cfg, rel)); } catch (e) { res.writeHead(400); return res.end('Bad path'); }
  const lib = u.protocol === 'https:' ? https : http;
  const headers = { Authorization: webdavAuthHeader(cfg) };
  if (req.headers.range) headers.Range = req.headers.range;   // forward range for seeking
  const rq = lib.request({ method: 'GET', hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80), path: u.pathname + u.search, headers, timeout: 30000 }, up => {
    if (up.statusCode >= 400) { up.resume(); res.writeHead(up.statusCode === 404 ? 404 : 502, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ message: 'WebDAV returned HTTP ' + up.statusCode })); }
    const ext = (name.split('.').pop() || '').toLowerCase();
    const h = {
      'Content-Type': up.headers['content-type'] || VIDEO_MIME[ext] || 'application/octet-stream',
      'Accept-Ranges': up.headers['accept-ranges'] || 'bytes',
      'Cache-Control': 'no-store'
    };
    if (up.headers['content-length']) h['Content-Length'] = up.headers['content-length'];
    if (up.headers['content-range'])  h['Content-Range']  = up.headers['content-range'];
    res.writeHead(up.statusCode, h);   // 200 (full) or 206 (partial)
    up.pipe(res);
  });
  rq.on('error', err => { if (!res.headersSent) { res.writeHead(502, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'WebDAV error: ' + err.message })); } else { res.end(); } });
  rq.on('timeout', () => rq.destroy(new Error('Connection timed out')));
  req.on('close', () => rq.destroy());   // stop pulling from WebDAV if the player disconnects
  rq.end();
}
// Transcode on the fly so incompatible files play in the browser. Probes the source first and re-encodes
// only what the browser can't handle: video → H.264 (HEVC/H.265, MPEG-2, VC-1, 10-bit Hi10P, …) and/or
// audio → AAC (AC3/E-AC3/DTS/TrueHD, multichannel). Compatible streams are copied to save CPU.
// opts: { ac:'2' downmix audio to stereo, vc:'1' force video re-encode }. Live transcode — seeking is limited.
const VIDEO_OK = ['h264', 'vp8', 'vp9', 'av1'];
const AUDIO_OK = ['aac', 'mp3'];
function ffprobeCodecs (inputUrl, cb) {
  if (!FFPROBE) return cb(null);
  let fp; try { fp = spawn(FFPROBE, ['-v', 'error', '-show_entries', 'format=duration:stream=codec_type,codec_name,pix_fmt', '-of', 'json', inputUrl]); } catch (e) { return cb(null); }
  let out = ''; const t = setTimeout(() => { try { fp.kill('SIGKILL'); } catch (e) {} }, 12000);
  fp.stdout.on('data', d => { out += d; }); fp.stderr.on('data', () => {});
  fp.on('error', () => { clearTimeout(t); cb(null); });
  fp.on('close', () => {
    clearTimeout(t);
    try {
      const j = JSON.parse(out); const streams = j.streams || [];
      const v = streams.find(s => s.codec_type === 'video') || {};
      const a = streams.find(s => s.codec_type === 'audio') || {};
      const dur = j.format && parseFloat(j.format.duration);
      cb({ video: (v.codec_name || '').toLowerCase(), pix: (v.pix_fmt || '').toLowerCase(), audio: (a.codec_name || '').toLowerCase(), duration: (dur && isFinite(dur)) ? dur : 0 });
    } catch (e) { cb(null); }
  });
}
// Video encoder args for a quality preset. 'orig' = source resolution, visually-lossless CRF; lower tiers cap resolution.
const SEG_TIME = 6;
function qualityVideoArgs (q) {
  const cfg = readConfig().webdav;
  const cap = q === '480' ? 854 : q === '720' ? 1280 : q === '1080' ? 1920 : 0;
  const scale = cap ? ['-vf', "scale='min(" + cap + ",iw)':-2"] : [];
  const kf = ['-force_key_frames', 'expr:gte(t,n_forced*' + SEG_TIME + ')', '-g', '144', '-sc_threshold', '0'];
  const hw = cfg.hwAccel !== 'off' ? HWENC : null;
  if (hw === 'h264_nvenc') {
    const cq = q === '480' ? '26' : q === '720' ? '24' : q === '1080' ? '23' : '21';
    return ['-c:v', 'h264_nvenc', '-preset', 'p5', '-rc', 'vbr', '-cq', cq, '-b:v', '0', '-pix_fmt', 'yuv420p', '-profile:v', 'high'].concat(kf, scale);
  }
  if (hw === 'h264_qsv') {
    const gq = q === '480' ? '26' : q === '720' ? '24' : q === '1080' ? '23' : '21';
    return ['-c:v', 'h264_qsv', '-preset', 'veryfast', '-global_quality', gq, '-pix_fmt', 'nv12', '-profile:v', 'high'].concat(kf, scale);
  }
  if (hw === 'h264_videotoolbox') {
    const br = q === '480' ? '2500k' : q === '720' ? '4500k' : q === '1080' ? '8000k' : '12000k';
    return ['-c:v', 'h264_videotoolbox', '-b:v', br, '-profile:v', 'high', '-pix_fmt', 'yuv420p'].concat(kf, scale);
  }
  // software (libx264) — speed preset chosen by the admin
  const crf = q === '480' ? '24' : q === '720' ? '22' : q === '1080' ? '20' : '18';
  const preset = ENC_PRESET[cfg.encSpeed] || 'veryfast';
  return ['-c:v', 'libx264', '-preset', preset, '-crf', crf, '-pix_fmt', 'yuv420p', '-profile:v', 'high', '-level', '4.1'].concat(kf, scale);
}
function webdavTranscode (cfg, rel, name, opts, req, res) {
  opts = opts || {};
  let inputUrl;
  try { const du = new URL(webdavTarget(cfg, rel)); if (cfg.username) { du.username = encodeURIComponent(cfg.username); du.password = encodeURIComponent(cfg.password || ''); } inputUrl = du.toString(); }
  catch (e) { res.writeHead(400); return res.end('Bad path'); }

  ffprobeCodecs(inputUrl, info => {
    const forceVideo = opts.vc === '1';
    const forceStereo = opts.ac === '2';
    // Decide video: re-encode if forced, if probe says an unsupported codec, if 10/12-bit, or (probe failed) leave as copy to stay cheap.
    let doVideo;
    if (forceVideo) doVideo = true;
    else if (!info || !info.video) doVideo = false;                     // unknown → copy (cheap); user can force if it won't play
    else { const tenBit = /10|12/.test(info.pix); doVideo = !VIDEO_OK.includes(info.video) || tenBit; }
    // Decide audio: re-encode if forced stereo, if probe says non-AAC/MP3, or (probe failed) re-encode to AAC to be safe.
    let doAudio;
    const aidx = (opts.aidx != null && opts.aidx !== '') ? Math.max(0, parseInt(opts.aidx, 10) || 0) : null;
    if (forceStereo) doAudio = true;
    else if (aidx != null) doAudio = true;                              // a specific track was chosen → encode it to AAC
    else if (!info || !info.audio) doAudio = true;                      // unknown → AAC (the usual reason people transcode)
    else doAudio = !AUDIO_OK.includes(info.audio);

    const args = ['-hide_banner', '-loglevel', 'error', '-i', inputUrl, '-map', '0:v:0?', '-map', '0:a:' + (aidx != null ? aidx : 0) + '?'];
    if (doVideo) args.push('-c:v', 'libx264', '-preset', (ENC_PRESET[cfg.encSpeed] || 'veryfast'), '-crf', '23', '-pix_fmt', 'yuv420p', '-g', '48', '-sc_threshold', '0');
    else args.push('-c:v', 'copy');
    if (doAudio) { args.push('-c:a', 'aac', '-b:a', forceStereo ? '256k' : '448k'); if (forceStereo) args.push('-ac', '2'); }
    else args.push('-c:a', 'copy');
    args.push('-movflags', 'frag_keyframe+empty_moov+default_base_moof', '-f', 'mp4', 'pipe:1');

    let ff;
    try { ff = spawn(FFMPEG, args); } catch (e) { if (!res.headersSent) { res.writeHead(502, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'Could not start ffmpeg: ' + e.message })); } return; }
    let started = false, errBuf = '';
    ff.stderr.on('data', d => { errBuf += d.toString(); if (errBuf.length > 4000) errBuf = errBuf.slice(-4000); });
    ff.stdout.once('data', chunk => { started = true; res.writeHead(200, { 'Content-Type': 'video/mp4', 'Cache-Control': 'no-store' }); res.write(chunk); ff.stdout.pipe(res); });
    ff.on('error', e => { if (!started && !res.headersSent) { res.writeHead(502, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'ffmpeg error: ' + e.message })); } else { try { res.end(); } catch (_) {} } });
    ff.on('close', code => { if (!started && !res.headersSent) { res.writeHead(502, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'Transcode failed: ' + (errBuf.split('\n').filter(Boolean).pop() || ('ffmpeg exited ' + code)) })); } else { try { res.end(); } catch (_) {} } });
    const kill = () => { try { ff.kill('SIGKILL'); } catch (e) {} };
    req.on('close', kill); res.on('close', kill);
  });
}
// --- Seekable HLS transcode ---
// Builds a full VOD playlist up front (so the player can seek anywhere) and transcodes on demand:
// segments are produced linearly, and when the player seeks to a segment that isn't ready yet, the
// encoder is restarted at that point (-ss) with timestamps preserved (-copyts) so the timeline stays aligned.
function segName (k) { return 'seg' + String(k).padStart(5, '0') + '.ts'; }
function hlsSpawn (sess, k) {
  if (sess.ff) { try { sess.ff.kill('SIGKILL'); } catch (e) {} sess.ff = null; }
  const a = ['-hide_banner', '-loglevel', 'error'];
  if (k > 0) a.push('-copyts', '-start_at_zero', '-ss', String(k * SEG_TIME));
  a.push('-i', sess.inputUrl, '-map', '0:v:0?', '-map', '0:a:' + (sess.aidx != null ? sess.aidx : 0) + '?');
  a.push.apply(a, qualityVideoArgs(sess.q));
  a.push('-c:a', 'aac', '-b:a', sess.ac === '2' ? '256k' : '448k'); if (sess.ac === '2') a.push('-ac', '2');
  a.push('-f', 'hls', '-hls_time', String(SEG_TIME), '-hls_list_size', '0', '-hls_flags', 'independent_segments+temp_file',
    '-hls_segment_type', 'mpegts', '-start_number', String(k),
    '-hls_segment_filename', path.join(sess.dir, 'seg%05d.ts'), path.join(sess.dir, '_ff.m3u8'));
  let ff; try { ff = spawn(FFMPEG, a); } catch (e) { sess.ff = null; sess.ffDone = true; sess.lastErr = e.message; return; }
  sess.ff = ff; sess.startSeg = k; sess.ffDone = false; sess.lastRestart = Date.now();
  ff.stderr.on('data', d => { sess.lastErr = (d.toString().split('\n').filter(Boolean).pop() || sess.lastErr); });
  ff.on('close', () => { if (sess.ff === ff) { sess.ffDone = true; } });
  ff.on('error', () => { if (sess.ff === ff) { sess.ffDone = true; } });
}
function hlsLastContig (sess) { let k = sess.startSeg; while (fs.existsSync(path.join(sess.dir, segName(k + 1)))) k++; return k; }
function hlsSegReady (sess, k) { return fs.existsSync(path.join(sess.dir, segName(k))); }   // temp_file flag → file appears only when finalized
function webdavHlsStart (rel, opts, res, req, user) {
  const cfg = readConfig().webdav;
  if (!cfg.url || !cfg.username) return sendJSON(res, 400, { message: 'WebDAV is not configured' });
  if (!FFMPEG) return sendJSON(res, 400, { message: 'ffmpeg is not available on the server' });
  const segs = safeSegments(rel); if (!segs.length) return sendJSON(res, 400, { message: 'No file specified' });
  logPlayOnce(user, rel, req);
  let inputUrl;
  try { const du = new URL(webdavTarget(cfg, rel)); if (cfg.username) { du.username = encodeURIComponent(cfg.username); du.password = encodeURIComponent(cfg.password || ''); } inputUrl = du.toString(); }
  catch (e) { return sendJSON(res, 400, { message: 'Bad path' }); }
  opts = opts || {};
  ffprobeCodecs(inputUrl, info => {
    const duration = (info && info.duration) ? info.duration : 0;
    if (!duration) return sendJSON(res, 502, { message: 'Could not read media duration' });
    const aidx = (opts.aidx != null && opts.aidx !== '') ? Math.max(0, parseInt(opts.aidx, 10) || 0) : null;
    const q = ['orig', '1080', '720', '480'].includes(opts.q) ? opts.q : 'orig';
    const nSegs = Math.max(1, Math.ceil(duration / SEG_TIME));
    const sid = crypto.randomBytes(9).toString('hex');
    const dir = path.join(HLS_ROOT, sid);
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { return sendJSON(res, 502, { message: 'Could not create temp dir' }); }
    // hand-write the full VOD playlist so the player has the whole timeline immediately
    let pl = '#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-TARGETDURATION:' + SEG_TIME + '\n#EXT-X-MEDIA-SEQUENCE:0\n';
    for (let i = 0; i < nSegs; i++) { const d = (i === nSegs - 1) ? (duration - (nSegs - 1) * SEG_TIME) : SEG_TIME; pl += '#EXTINF:' + (d > 0 ? d.toFixed(3) : SEG_TIME.toFixed(3)) + ',\n' + segName(i) + '\n'; }
    pl += '#EXT-X-ENDLIST\n';
    try { fs.writeFileSync(path.join(dir, 'index.m3u8'), pl); } catch (e) { return sendJSON(res, 502, { message: 'Could not write playlist' }); }
    const sess = { dir, inputUrl, aidx, ac: opts.ac, q, duration, nSegs, ff: null, startSeg: 0, ffDone: false, last: Date.now(), lastErr: '' };
    hlsSessions.set(sid, sess);
    hlsSpawn(sess, 0);
    const t0 = Date.now();
    const check = () => {
      if (!hlsSessions.has(sid)) return;
      if (hlsSegReady(sess, 0) || fs.existsSync(path.join(dir, segName(0)))) return sendJSON(res, 200, { sid, duration, segTime: SEG_TIME, quality: q });
      if (sess.ffDone && !fs.existsSync(path.join(dir, segName(0)))) { const e = sess.lastErr || 'ffmpeg exited before producing output'; hlsCleanup(sid); return sendJSON(res, 502, { message: 'Transcode failed: ' + e }); }
      if (Date.now() - t0 > 25000) { hlsCleanup(sid); return sendJSON(res, 504, { message: 'Transcode did not start in time' }); }
      setTimeout(check, 200);
    };
    setTimeout(check, 250);
  });
}
function webdavHlsFile (sid, file, res) {
  const sess = hlsSessions.get(sid);
  if (!sess) { res.writeHead(404); return res.end('session expired'); }
  if (!/^[A-Za-z0-9_.-]+$/.test(file) || file.indexOf('..') !== -1) { res.writeHead(400); return res.end('bad'); }
  sess.last = Date.now();
  const serve = () => fs.readFile(path.join(sess.dir, file), (e, buf) => {
    if (e) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'Content-Type': file.endsWith('.m3u8') ? 'application/vnd.apple.mpegurl' : 'video/mp2t', 'Cache-Control': 'no-store' });
    res.end(buf);
  });
  if (file.endsWith('.m3u8')) return serve();
  const m = file.match(/^seg(\d+)\.ts$/); if (!m) { res.writeHead(404); return res.end('not found'); }
  const k = parseInt(m[1], 10);
  if (hlsSegReady(sess, k)) return serve();
  // not ready: make sure an encoder is producing this segment (restart on a seek)
  const alive = sess.ff && !sess.ffDone;
  const contig = alive ? hlsLastContig(sess) : -1;
  const needRestart = !alive || k < sess.startSeg || (k - contig) > 10;
  if (needRestart && (Date.now() - (sess.lastRestart || 0) > 1200 || k < sess.startSeg)) hlsSpawn(sess, k);
  const t0 = Date.now();
  const wait = () => {
    if (!hlsSessions.has(sid)) { res.writeHead(404); return res.end('gone'); }
    if (hlsSegReady(sess, k)) return serve();
    if (sess.ffDone && !fs.existsSync(path.join(sess.dir, segName(k)))) { res.writeHead(404); return res.end('segment unavailable'); }
    if (Date.now() - t0 > 30000) { res.writeHead(504); return res.end('segment timeout'); }
    setTimeout(wait, 200);
  };
  wait();
}
function webdavHlsStop (sid, res) { hlsCleanup(sid); res.writeHead(204); res.end(); }
// List the audio + (text) subtitle tracks in a file so the player can offer track selection.
const TEXT_SUBS = ['subrip', 'srt', 'ass', 'ssa', 'mov_text', 'webvtt', 'text', 'dvb_teletext'];
function webdavTracks (rel, res) {
  const cfg = readConfig().webdav;
  if (!cfg.url || !cfg.username) return sendJSON(res, 400, { message: 'WebDAV is not configured' });
  if (!FFPROBE) return sendJSON(res, 200, { audio: [], subs: [] });
  const segs = safeSegments(rel); if (!segs.length) return sendJSON(res, 400, { message: 'No file specified' });
  let inputUrl;
  try { const du = new URL(webdavTarget(cfg, rel)); if (cfg.username) { du.username = encodeURIComponent(cfg.username); du.password = encodeURIComponent(cfg.password || ''); } inputUrl = du.toString(); }
  catch (e) { return sendJSON(res, 400, { message: 'Bad path' }); }
  let fp; try { fp = spawn(FFPROBE, ['-v', 'error', '-show_entries', 'stream=index,codec_type,codec_name,channels:stream_tags=language,title', '-of', 'json', inputUrl]); }
  catch (e) { return sendJSON(res, 200, { audio: [], subs: [] }); }
  let out = ''; const t = setTimeout(() => { try { fp.kill('SIGKILL'); } catch (e) {} }, 12000);
  fp.stdout.on('data', d => { out += d; }); fp.stderr.on('data', () => {});
  fp.on('error', () => { clearTimeout(t); sendJSON(res, 200, { audio: [], subs: [] }); });
  fp.on('close', () => {
    clearTimeout(t);
    let streams = []; try { streams = (JSON.parse(out).streams) || []; } catch (e) {}
    const audio = [], subs = []; let ai = 0, si = 0;
    for (const s of streams) {
      const tags = s.tags || {};
      const lang = tags.language || tags.LANGUAGE || '';
      const title = tags.title || tags.TITLE || '';
      if (s.codec_type === 'audio') audio.push({ i: ai++, codec: s.codec_name || '', channels: s.channels || 0, lang, title });
      else if (s.codec_type === 'subtitle') subs.push({ i: si++, codec: s.codec_name || '', lang, title, text: TEXT_SUBS.includes((s.codec_name || '').toLowerCase()) });
    }
    sendJSON(res, 200, { audio, subs });
  });
}
// Extract one text subtitle track to WebVTT so the player can show it as a <track>.
function webdavSubtitle (rel, sidx, res) {
  const cfg = readConfig().webdav;
  if (!cfg.url || !cfg.username) { res.writeHead(400); return res.end('WebDAV not configured'); }
  if (!FFMPEG) { res.writeHead(400); return res.end('ffmpeg unavailable'); }
  const segs = safeSegments(rel); if (!segs.length) { res.writeHead(400); return res.end('No file'); }
  const n = parseInt(sidx, 10); if (isNaN(n) || n < 0) { res.writeHead(400); return res.end('Bad subtitle index'); }
  let inputUrl;
  try { const du = new URL(webdavTarget(cfg, rel)); if (cfg.username) { du.username = encodeURIComponent(cfg.username); du.password = encodeURIComponent(cfg.password || ''); } inputUrl = du.toString(); }
  catch (e) { res.writeHead(400); return res.end('Bad path'); }
  let ff; try { ff = spawn(FFMPEG, ['-hide_banner', '-loglevel', 'error', '-i', inputUrl, '-map', '0:s:' + n, '-f', 'webvtt', 'pipe:1']); }
  catch (e) { res.writeHead(502); return res.end('ffmpeg failed'); }
  let started = false;
  ff.stderr.on('data', () => {});
  ff.stdout.once('data', chunk => { started = true; res.writeHead(200, { 'Content-Type': 'text/vtt; charset=utf-8', 'Cache-Control': 'no-store' }); res.write(chunk); ff.stdout.pipe(res); });
  ff.on('error', () => { if (!started && !res.headersSent) { res.writeHead(502); res.end('ffmpeg error'); } });
  ff.on('close', () => { if (!started && !res.headersSent) { res.writeHead(502, { 'Content-Type': 'text/plain' }); res.end('Could not extract subtitle'); } else { try { res.end(); } catch (_) {} } });
  res.on('close', () => { try { ff.kill('SIGKILL'); } catch (e) {} });
}
async function testWebdav (url, username, password, folder) {
  const base = normUrl(url);
  if (!base || !username) throw new Error('Missing URL or username');
  const cfg = { url: base, username, password: password || readConfig().webdav.password, folder };
  const target = webdavTarget(cfg, '');
  const up = await upstream(target.endsWith('/') ? target : target + '/', {
    method: 'PROPFIND',
    headers: { Authorization: webdavAuthHeader(cfg), Depth: '1', 'Content-Type': 'application/xml', Accept: 'application/xml' }
  });
  if (up.status === 401) throw new Error('Unauthorized — check username/password');
  if (up.status === 404) throw new Error('Folder not found on the server');
  if (up.status >= 400)  throw new Error('Server returned HTTP ' + up.status);
  const entries = parsePropfind(up.body.toString('utf8'));
  const vids = entries.filter(e => !e.isDir && (VIDEO_EXT.includes((e.name.split('.').pop() || '').toLowerCase()))).length;
  return { name: 'WebDAV', videos: vids, folders: entries.filter(e => e.isDir).length };
}

/* ---------- auto add queue (server-side, survives page reloads) ---------- */
async function arrPost (svc, subPath, bodyObj) {
  const cfg = readConfig()[svc];
  if (!cfg.url || !cfg.apiKey) return { ok: false, message: svc + ' is not configured' };
  try {
    const body = Buffer.from(JSON.stringify(bodyObj));
    const up = await upstream(normUrl(cfg.url) + subPath, { method: 'POST', headers: { 'X-Api-Key': cfg.apiKey, 'Content-Type': 'application/json', 'Content-Length': body.length }, body });
    if (up.status >= 400) {
      let msg = 'HTTP ' + up.status;
      try { const j = JSON.parse(up.body.toString('utf8')); if (Array.isArray(j) && j[0] && j[0].errorMessage) msg = j[0].errorMessage; else if (j.message) msg = j.message; } catch (e) {}
      return { ok: false, message: msg };
    }
    return { ok: true };
  } catch (e) { return { ok: false, message: e.message }; }
}
let autoJob = null, autoTimer = null;
function readAutoJob () { try { return JSON.parse(fs.readFileSync(AUTOADD_PATH, 'utf8')); } catch (e) { return null; } }
function saveAutoJob () { try { if (autoJob) fs.writeFileSync(AUTOADD_PATH, JSON.stringify(autoJob)); else fs.rmSync(AUTOADD_PATH, { force: true }); } catch (e) {} }
function autoStatus () {
  if (!autoJob) return { running: false, job: null };
  const j = autoJob;
  return { running: j.status === 'running', job: {
    label: j.label, status: j.status, total: j.items.length, index: j.index,
    added: j.added, skipped: j.skipped, failed: j.failed, tooShort: j.tooShort || 0, minRuntime: j.minRuntime || 0,
    intervalMinutes: j.intervalMinutes, startedAt: j.startedAt, nextAt: j.nextAt || null,
    user: j.username, log: j.log.slice(-40)
  } };
}
function autoLog (icon, title, msg) { autoJob.log.push({ ts: Date.now(), icon, title, msg }); if (autoJob.log.length > 300) autoJob.log.splice(0, autoJob.log.length - 300); }
function autoFinish (status) {
  if (!autoJob) return;
  autoJob.status = status; autoJob.nextAt = null;
  if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
  saveAutoJob();
}
async function autoStep () {
  if (!autoJob || autoJob.status !== 'running') return;
  if (autoJob.index >= autoJob.items.length) return autoFinish('done');
  const it = autoJob.items[autoJob.index++];
  const isMovie = it.kind !== 'series';
  const svc = isMovie ? 'radarr' : 'sonarr';
  const cfg = readConfig()[svc];
  try {
    if (!cfg.url || !cfg.apiKey) { autoJob.failed++; autoLog('⚠', it.title, svc + ' not configured'); }
    else if (autoJob.role !== 'admin' && autoJob.dailyLimit > 0 && addsTodayCount(autoJob.username) >= autoJob.dailyLimit) {
      autoLog('⏹', it.title, 'daily add limit reached — stopping'); autoFinish('stopped'); saveAutoJob(); return;
    } else {
      let term = '', found = null;
      if (isMovie) {
        term = it.tmdbId ? ('tmdb:' + it.tmdbId) : (it.imdbId ? ('imdb:' + it.imdbId) : encodeURIComponent(it.title || ''));
        found = await arrJson('radarr', '/api/v3/movie/lookup?term=' + term);
      } else {
        let imdb = it.imdbId || '';
        if (!imdb && it.tmdbId) { const ext = await tmdbJson('/tv/' + it.tmdbId + '/external_ids'); if (ext) imdb = ext.imdb_id || ''; }
        term = imdb ? ('imdb:' + imdb) : (it.tvdbId ? ('tvdb:' + it.tvdbId) : encodeURIComponent(it.title || ''));
        found = await arrJson('sonarr', '/api/v3/series/lookup?term=' + term);
      }
      const obj = (found && found.length) ? ((it.imdbId && found.find(f => f.imdbId === it.imdbId)) || found[0]) : null;
      if (!obj) { autoJob.failed++; autoLog('⚠', it.title, 'not found'); }
      else if (obj.id) { autoJob.skipped++; autoLog('•', it.title, 'already in library'); }
      else {
        // runtime gate: Radarr gives a movie's length, Sonarr an episode's; fall back to TMDB.
        let runtime = Number(obj.runtime) || 0;
        const minRt = Number(autoJob.minRuntime) || 0;
        if (minRt > 0 && !runtime) {
          const id = it.tmdbId || obj.tmdbId;
          if (id) {
            const d = await tmdbJson((isMovie ? '/movie/' : '/tv/') + id);
            if (d) runtime = isMovie ? (Number(d.runtime) || 0) : (Array.isArray(d.episode_run_time) && d.episode_run_time.length ? Number(d.episode_run_time[0]) || 0 : 0);
          }
        }
        if (minRt > 0 && runtime > 0 && runtime < minRt) {
          autoJob.tooShort = (autoJob.tooShort || 0) + 1;
          autoLog('⏱', it.title, runtime + ' min — under the ' + minRt + ' min minimum');
        } else {
          const body = isMovie
            ? Object.assign({}, obj, { qualityProfileId: Number(cfg.qualityProfileId) || 1, rootFolderPath: cfg.rootFolderPath, monitored: true, minimumAvailability: 'released', addOptions: { searchForMovie: true } })
            : Object.assign({}, obj, { qualityProfileId: Number(cfg.qualityProfileId) || 1, rootFolderPath: cfg.rootFolderPath, monitored: true, seasonFolder: true, addOptions: { monitor: 'all', searchForMissingEpisodes: true } });
          const r = await arrPost(svc, isMovie ? '/api/v3/movie' : '/api/v3/series', body);
          if (r.ok) {
            autoJob.added++; autoLog('✓', it.title, 'added' + (runtime ? ' · ' + runtime + ' min' : ''));
            logAdd({ ts: Date.now(), username: autoJob.username, role: autoJob.role, service: svc, type: isMovie ? 'movie' : 'series', title: it.title || obj.title, year: obj.year || '', ip: autoJob.ip || '' });
          } else { autoJob.failed++; autoLog('⚠', it.title, r.message || 'add failed'); }
        }
      }
    }
  } catch (e) { autoJob.failed++; autoLog('⚠', it.title, e.message || 'error'); }

  if (autoJob.index >= autoJob.items.length) { autoFinish('done'); return; }
  const delay = Math.max(0, autoJob.intervalMinutes * 60000);
  autoJob.nextAt = Date.now() + delay;
  saveAutoJob();
  autoTimer = setTimeout(autoStep, delay);
}
// Resume an interrupted job after a restart.
(function resumeAutoJob () {
  const j = readAutoJob();
  if (j && j.status === 'running' && j.index < j.items.length) {
    autoJob = j;
    const wait = Math.max(3000, (j.nextAt || 0) - Date.now());
    autoTimer = setTimeout(autoStep, wait);
    try { console.log('[mediarr] resuming auto-add: ' + j.index + '/' + j.items.length); } catch (e) {}
  } else if (j) { autoJob = j; }
})();

/* ---------- public API (per-user key) ---------- */
async function apiV1 (sub, req, res, u, me) {
  const method = req.method;
  if (sub === '/ping' && method === 'GET') {
    return sendJSON(res, 200, { ok: true, user: me.username, role: me.role, dailyLimit: me.dailyLimit || 0, addedToday: addsTodayCount(me.username) });
  }
  if (sub === '/search' && method === 'GET') {
    const q = (u.searchParams.get('q') || u.searchParams.get('query') || '').trim();
    if (!q) return sendJSON(res, 400, { error: 'Missing q' });
    const type = (u.searchParams.get('type') || 'all').toLowerCase();
    const limit = Math.min(50, Number(u.searchParams.get('limit')) || 20);
    if (!readConfig().tmdb.apiKey) return sendJSON(res, 400, { error: 'TMDB is not configured on this server' });
    const want = type === 'movie' ? ['movie'] : (type === 'series' || type === 'tv') ? ['tv'] : ['movie', 'tv'];
    const out = [];
    for (const t of want) {
      const d = await tmdbJson('/search/' + t + '?query=' + encodeURIComponent(q) + '&include_adult=false');
      for (const r of ((d && d.results) || [])) {
        out.push({
          type: t === 'tv' ? 'series' : 'movie',
          title: r.title || r.name || '',
          year: (r.release_date || r.first_air_date || '').slice(0, 4),
          tmdbId: r.id, overview: (r.overview || '').slice(0, 500),
          poster: r.poster_path ? ('https://image.tmdb.org/t/p/w500' + r.poster_path) : '',
          rating: r.vote_average || null
        });
      }
    }
    out.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    return sendJSON(res, 200, { query: q, count: Math.min(out.length, limit), results: out.slice(0, limit) });
  }
  if (sub === '/library' && method === 'GET') {
    const type = (u.searchParams.get('type') || 'all').toLowerCase();
    const out = {};
    if (type !== 'series' && type !== 'tv') {
      const m = await arrJson('radarr', '/api/v3/movie');
      out.movies = (m || []).map(x => ({ title: x.title, year: x.year, tmdbId: x.tmdbId, imdbId: x.imdbId || '', hasFile: !!x.hasFile }));
    }
    if (type !== 'movie') {
      const s = await arrJson('sonarr', '/api/v3/series');
      out.series = (s || []).map(x => ({ title: x.title, year: x.year, tvdbId: x.tvdbId, imdbId: x.imdbId || '' }));
    }
    return sendJSON(res, 200, out);
  }
  if (sub === '/add' && method === 'POST') {
    let b = {}; try { b = JSON.parse((await readBody(req)) || '{}'); } catch (e) {}
    const t = String(b.type || 'movie').toLowerCase();
    const isMovie = t !== 'series' && t !== 'tv' && t !== 'show';
    const svc = isMovie ? 'radarr' : 'sonarr';
    const cfg = readConfig()[svc];
    if (!cfg.url || !cfg.apiKey) return sendJSON(res, 400, { error: svc + ' is not configured' });
    if (me.role !== 'admin' && me.dailyLimit > 0 && addsTodayCount(me.username) >= me.dailyLimit) {
      return sendJSON(res, 429, { error: 'Daily add limit reached (' + me.dailyLimit + ')' });
    }
    let term = '';
    if (isMovie) term = b.tmdbId ? ('tmdb:' + b.tmdbId) : b.imdbId ? ('imdb:' + b.imdbId) : (b.title ? encodeURIComponent(b.title) : '');
    else {
      let imdb = b.imdbId || '';
      if (!imdb && b.tmdbId) { const ext = await tmdbJson('/tv/' + b.tmdbId + '/external_ids'); if (ext) imdb = ext.imdb_id || ''; }
      term = imdb ? ('imdb:' + imdb) : b.tvdbId ? ('tvdb:' + b.tvdbId) : (b.title ? encodeURIComponent(b.title) : '');
    }
    if (!term) return sendJSON(res, 400, { error: 'Provide tmdbId, imdbId, tvdbId or title' });
    const found = await arrJson(svc, (isMovie ? '/api/v3/movie/lookup?term=' : '/api/v3/series/lookup?term=') + term);
    const obj = (found && found.length) ? found[0] : null;
    if (!obj) return sendJSON(res, 404, { error: 'Not found' });
    if (obj.id) return sendJSON(res, 200, { ok: true, added: false, alreadyInLibrary: true, title: obj.title });
    const body = isMovie
      ? Object.assign({}, obj, { qualityProfileId: Number(b.qualityProfileId || cfg.qualityProfileId) || 1, rootFolderPath: b.rootFolderPath || cfg.rootFolderPath, monitored: b.monitored !== false, minimumAvailability: b.minimumAvailability || 'released', addOptions: { searchForMovie: b.search !== false } })
      : Object.assign({}, obj, { qualityProfileId: Number(b.qualityProfileId || cfg.qualityProfileId) || 1, rootFolderPath: b.rootFolderPath || cfg.rootFolderPath, monitored: b.monitored !== false, seasonFolder: true, addOptions: { monitor: b.monitor || 'all', searchForMissingEpisodes: b.search !== false } });
    const r = await arrPost(svc, isMovie ? '/api/v3/movie' : '/api/v3/series', body);
    if (!r.ok) return sendJSON(res, 502, { error: r.message || 'Add failed' });
    logAdd({ ts: Date.now(), username: me.username, role: me.role, service: svc, type: isMovie ? 'movie' : 'series', title: obj.title, year: obj.year || '', ip: clientIp(req) });
    return sendJSON(res, 201, { ok: true, added: true, title: obj.title, year: obj.year || '', service: svc });
  }
  sendJSON(res, 404, { error: 'Unknown endpoint. Try /api/v1/ping, /api/v1/search, /api/v1/library or /api/v1/add' });
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const p = u.pathname;

  try {
    // static (login screen is part of the SPA; the APIs below are protected)
    if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
      const ua = (req.headers['user-agent'] || '').toLowerCase();
      const isMobileUA = /android|iphone|ipod|iemobile|blackberry|opera mini|mobile/.test(ua);
      const forceDesktop = /[?&]d=1\b/.test(req.url || '');
      if (isMobileUA && !forceDesktop) { res.writeHead(302, { Location: '/m' }); return res.end(); }
      return serveStatic(res, 'index.html');
    }
    if (req.method === 'GET' && (p === '/m' || p === '/m/' || p === '/mobile' || p === '/mobile.html')) return serveStatic(res, 'mobile.html');
    if (req.method === 'GET' && p === '/bootstrap.min.css') return serveVendor(res, 'bootstrap.min.css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css');
    if (req.method === 'GET' && p === '/bootstrap.bundle.min.js') return serveVendor(res, 'bootstrap.bundle.min.js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js');
    if (req.method === 'GET' && p === '/hls.min.js') return serveVendor(res, 'hls.min.js', 'https://cdn.jsdelivr.net/npm/hls.js@1.5.13/dist/hls.min.js');

    // ---- auth (open) ----
    if (p === '/api/setup-needed' && req.method === 'GET') {
      return sendJSON(res, 200, { needed: readUsers().users.length === 0, loginTheme: (readConfig().ui || {}).loginTheme || 'tron' });
    }
    if (p === '/api/setup' && req.method === 'POST') {
      const data = readUsers();
      if (data.users.length) return sendJSON(res, 403, { message: 'Setup already complete' });
      const { username, password } = JSON.parse(await readBody(req) || '{}');
      if (!username || !password) return sendJSON(res, 400, { message: 'Username and password required' });
      const { salt, hash } = hashPassword(password);
      const u = { username: String(username).trim(), role: 'admin', dailyLimit: 0, salt, hash, createdAt: Date.now() };
      data.users.push(u); writeUsers(data);
      createSession(req, res, u.username);
      return sendJSON(res, 200, publicUser(u, true));
    }
    if (p === '/api/login' && req.method === 'POST') {
      const { username, password } = JSON.parse(await readBody(req) || '{}');
      const u = findUser(username);
      if (!u || !verifyPassword(password, u.salt, u.hash)) return sendJSON(res, 401, { message: 'Invalid username or password' });
      createSession(req, res, u.username);
      return sendJSON(res, 200, publicUser(u, true));
    }
    if (p === '/api/logout' && req.method === 'POST') { clearSession(req, res); return sendJSON(res, 200, { ok: true }); }
    if (p === '/api/me' && req.method === 'GET') {
      const u = currentUser(req);
      if (!u) return sendJSON(res, 401, { message: 'Not logged in' });
      return sendJSON(res, 200, publicUser(u, true));
    }

    // ---- everything else under /api requires a session ----
    if (p.startsWith('/api/v1/')) {
      const key = apiKeyFromReq(req, u);
      if (!key) return sendJSON(res, 401, { error: 'Missing API key. Send it as an X-API-Key header or ?api_key=' });
      const who = findUserByApiKey(key);
      if (!who) return sendJSON(res, 401, { error: 'Invalid API key' });
      return apiV1(p.slice('/api/v1'.length), req, res, u, who);
    }
    if (p.startsWith('/api/')) {
      const me = currentUser(req);
      if (!me) return sendJSON(res, 401, { message: 'Not logged in' });
      const adminOnly = (p === '/api/config' && req.method === 'POST') || p.startsWith('/api/admin/') || (p === '/api/plex/scan' && req.method === 'POST');
      if (adminOnly && me.role !== 'admin') return sendJSON(res, 403, { message: 'Admin only' });

      // ---- Plex: trigger a library scan (admin) ----
      if (p === '/api/plex/scan' && req.method === 'POST') return plexScan(res);

      // ---- per-user theme + personal API key ----
      if (p === '/api/me/theme' && req.method === 'GET') return sendJSON(res, 200, userTheme(me.username));
      if (p === '/api/me/theme' && req.method === 'POST') {
        let b = {}; try { b = JSON.parse((await readBody(req)) || '{}'); } catch (e) {}
        const t = sanitizeTheme(b);
        setUserField(me.username, 'theme', t);
        return sendJSON(res, 200, t);
      }
      if (p === '/api/me/theme' && req.method === 'DELETE') { setUserField(me.username, 'theme', null); return sendJSON(res, 200, { base: 'dark', modes: { dark: {}, light: {} } }); }
      if (p === '/api/me/apikey' && req.method === 'GET') {
        const u2 = findUser(me.username);
        return sendJSON(res, 200, { apiKey: (u2 && u2.apiKey) || '' });
      }
      if (p === '/api/me/apikey' && req.method === 'POST') {
        const key = newApiKey(); setUserField(me.username, 'apiKey', key);
        return sendJSON(res, 200, { apiKey: key });
      }
      if (p === '/api/me/apikey' && req.method === 'DELETE') { setUserField(me.username, 'apiKey', null); return sendJSON(res, 200, { apiKey: '' }); }

      // ---- per-user Plex account ----
      if (p === '/api/plex/user/status' && req.method === 'GET') {
        const px = getUserPlex(me.username);
        return sendJSON(res, 200, { linked: !!(px && px.token), username: (px && px.username) || '', serverConfigured: !!readConfig().plex.url });
      }
      if (p === '/api/plex/user/pin' && req.method === 'POST') {
        const clientId = ensurePlexClientId();
        try {
          const up = await upstream('https://plex.tv/api/v2/pins?strong=true', { method: 'POST', headers: Object.assign({ 'Content-Length': '0' }, plexHeaders(clientId)) });
          if (up.status < 200 || up.status >= 300) return sendJSON(res, 502, { message: 'Plex returned HTTP ' + up.status });
          const j = JSON.parse(up.body.toString('utf8'));
          return sendJSON(res, 200, { id: j.id, code: j.code, authUrl: 'https://app.plex.tv/auth#?clientID=' + encodeURIComponent(clientId) + '&code=' + encodeURIComponent(j.code) + '&context%5Bdevice%5D%5Bproduct%5D=MEDIARR' });
        } catch (e) { return sendJSON(res, 502, { message: 'Could not reach Plex: ' + e.message }); }
      }
      if (p === '/api/plex/user/check' && req.method === 'GET') {
        const id = (u.searchParams.get('id') || '').replace(/[^0-9]/g, '');
        if (!id) return sendJSON(res, 400, { message: 'Missing pin id' });
        const r = await plexJson('https://plex.tv/api/v2/pins/' + id, '');
        if (!r.ok) return sendJSON(res, 502, { message: 'Plex returned HTTP ' + r.status });
        const tok = r.data && r.data.authToken;
        if (!tok) return sendJSON(res, 200, { authorized: false });
        const acct = await plexJson('https://plex.tv/api/v2/user', tok);
        const info = acct.ok ? acct.data : {};
        setUserPlex(me.username, { token: tok, rootToken: tok, username: info.username || info.title || '', id: info.id || null, at: Date.now() });
        const home = await plexHomeUsers(tok);
        return sendJSON(res, 200, { authorized: true, username: info.username || info.title || '',
          homeUsers: home.users, multipleProfiles: home.users.length > 1 });
      }
      if (p === '/api/plex/user/home' && req.method === 'GET') {
        const px = getUserPlex(me.username);
        if (!px || !px.token) return sendJSON(res, 400, { message: 'Not signed in to Plex' });
        const h = await plexHomeUsers(px.token);
        return sendJSON(res, 200, { users: h.users, multiple: h.users.length > 1, current: px.username || '' });
      }
      if (p === '/api/plex/user/home/switch' && req.method === 'POST') {
        const px = getUserPlex(me.username);
        if (!px || !px.token) return sendJSON(res, 400, { message: 'Not signed in to Plex' });
        let b = {}; try { b = JSON.parse((await readBody(req)) || '{}'); } catch (e) {}
        if (b.id == null) return sendJSON(res, 400, { message: 'Missing profile id' });
        const base = px.rootToken || px.token;   // always switch from the account-level token
        const sw = await plexSwitchHomeUser(base, b.id, b.uuid || '', b.pin || '');
        if (!sw.ok) {
          const e = sw.err || {};
          const detail = e.message ? (': ' + e.message) : '';
          const hint = (e.status === 401 || e.status === 403) ? ' — the PIN was rejected.' : '';
          return sendJSON(res, 502, { message: 'Could not switch profile (HTTP ' + (e.status || '?') + detail + ')' + hint });
        }
        const acct = await plexJson('https://plex.tv/api/v2/user', sw.token);
        const info = acct.ok ? acct.data : {};
        setUserPlex(me.username, { token: sw.token, rootToken: base, username: info.username || info.title || '', id: info.id || null, at: Date.now() });
        return sendJSON(res, 200, { ok: true, username: info.username || info.title || '' });
      }
      if (p === '/api/plex/user/unlink' && req.method === 'POST') { setUserPlex(me.username, null); return sendJSON(res, 200, { linked: false }); }
      if (p === '/api/plex/watchlist' && req.method === 'GET') return plexWatchlist(me.username, res);
      if (p === '/api/plex/watchlist/add' && req.method === 'POST') {
        let b = {}; try { b = JSON.parse((await readBody(req)) || '{}'); } catch (e) {}
        return plexWatchlistAction(me.username, b, true, res);
      }
      if (p === '/api/plex/watchlist/remove' && req.method === 'POST') {
        let b = {}; try { b = JSON.parse((await readBody(req)) || '{}'); } catch (e) {}
        return plexWatchlistAction(me.username, b, false, res);
      }
      if (p === '/api/plex/history' && req.method === 'GET') {
        const lim = Math.min(500, Number(u.searchParams.get('limit')) || 200);
        return plexHistory(me.username, lim, res);
      }
      if (p === '/api/plex/img' && req.method === 'GET') return plexImage(me.username, u.searchParams.get('h') || 'pms', u.searchParams.get('p') || '', res);

      // ---- favorite TV shows (per user) ----
      if (p === '/api/favorites' && req.method === 'GET') {
        return sendJSON(res, 200, { favorites: userFavs(me.username) });
      }
      if (p === '/api/favorites' && req.method === 'POST') {
        let body = {};
        try { body = JSON.parse((await readBody(req)) || '{}'); } catch (e) {}
        const item = body.item || {};
        if (!item.title && !item.imdbId && !item.tmdbId && !item.tvdbId) return sendJSON(res, 400, { message: 'Nothing to favorite' });
        const f = readFavs(); if (!f.users) f.users = {};
        const list = f.users[me.username] || [];
        const key = favKey(item);
        const at = list.findIndex(x => x.key === key);
        let favorited;
        if (body.action === 'remove' || (body.action !== 'add' && at >= 0)) {
          if (at >= 0) list.splice(at, 1);
          favorited = false;
        } else {
          if (at < 0) list.push({ key, title: String(item.title || '').slice(0, 200), imdbId: item.imdbId || '', tvdbId: item.tvdbId || null, tmdbId: item.tmdbId || null, poster: String(item.poster || '').slice(0, 500), ts: Date.now() });
          favorited = true;
        }
        f.users[me.username] = list; writeFavs(f);
        return sendJSON(res, 200, { favorited, key, count: list.length });
      }
      if (p === '/api/favorites/upcoming' && req.method === 'GET') return favoritesUpcoming(me.username, res);

      // ---- auto add queue ----
      if (p === '/api/autoadd/status' && req.method === 'GET') return sendJSON(res, 200, autoStatus());
      if (p === '/api/autoadd/stop' && req.method === 'POST') {
        if (!autoJob || autoJob.status !== 'running') return sendJSON(res, 200, autoStatus());
        if (me.role !== 'admin' && autoJob.username !== me.username) return sendJSON(res, 403, { message: 'That job belongs to another user' });
        autoFinish('stopped'); autoLog('⏹', '', 'stopped by ' + me.username); saveAutoJob();
        return sendJSON(res, 200, autoStatus());
      }
      if (p === '/api/autoadd/start' && req.method === 'POST') {
        if (autoJob && autoJob.status === 'running') return sendJSON(res, 409, { message: 'An auto-add job is already running (' + autoJob.index + '/' + autoJob.items.length + ').' });
        let body = {};
        try { body = JSON.parse((await readBody(req)) || '{}'); } catch (e) {}
        const raw = Array.isArray(body.items) ? body.items : [];
        const items = raw.slice(0, 2000).map(x => ({
          kind: x.kind === 'series' ? 'series' : 'movie',
          tmdbId: x.tmdbId || null, imdbId: x.imdbId || '', tvdbId: x.tvdbId || null,
          title: String(x.title || '').slice(0, 200)
        })).filter(x => x.tmdbId || x.imdbId || x.tvdbId || x.title);
        if (!items.length) return sendJSON(res, 400, { message: 'Nothing to add' });
        const mins = Number(readConfig().autoAdd.intervalMinutes);
        autoJob = {
          label: String(body.label || 'Auto add').slice(0, 120),
          username: me.username, role: me.role, dailyLimit: me.dailyLimit || 0, ip: clientIp(req),
          items, index: 0, added: 0, skipped: 0, failed: 0, tooShort: 0, log: [],
          intervalMinutes: Number.isFinite(mins) ? mins : 5,
          minRuntime: Number(readConfig().autoAdd.minRuntime) || 0,
          status: 'running', startedAt: Date.now(), nextAt: null
        };
        autoLog('▶', '', 'queued ' + items.length + ' items · one every ' + autoJob.intervalMinutes + ' min' + (autoJob.minRuntime ? ' · skipping under ' + autoJob.minRuntime + ' min' : ''));
        saveAutoJob();
        if (autoTimer) clearTimeout(autoTimer);
        autoTimer = setTimeout(autoStep, 200);
        return sendJSON(res, 200, autoStatus());
      }
      if (p === '/api/plex/watched' && req.method === 'GET') {
        const w = await plexWatchedIndex();
        const shows = {}; for (const [k, v] of w.shows) shows[k] = v;
        return sendJSON(res, 200, { shows, episodes: w.set.size });
      }

      // ---- Plex sign-in (admin): OAuth PIN flow to capture a token + list servers ----
      if (p === '/api/admin/plex/pin' && req.method === 'POST') {
        const clientId = ensurePlexClientId();
        try {
          const up = await upstream('https://plex.tv/api/v2/pins?strong=true', { method: 'POST', headers: Object.assign({ 'Content-Length': '0' }, plexHeaders(clientId)) });
          if (up.status < 200 || up.status >= 300) return sendJSON(res, 502, { message: 'Plex returned HTTP ' + up.status });
          const j = JSON.parse(up.body.toString('utf8'));
          const authUrl = 'https://app.plex.tv/auth#?clientID=' + encodeURIComponent(clientId) + '&code=' + encodeURIComponent(j.code) + '&context%5Bdevice%5D%5Bproduct%5D=MEDIARR';
          return sendJSON(res, 200, { id: j.id, code: j.code, authUrl });
        } catch (e) { return sendJSON(res, 502, { message: 'Could not reach Plex: ' + e.message }); }
      }
      if (p === '/api/admin/plex/check' && req.method === 'GET') {
        const id = (u.searchParams.get('id') || '').replace(/[^0-9]/g, '');
        if (!id) return sendJSON(res, 400, { message: 'Missing pin id' });
        try {
          const up = await upstream('https://plex.tv/api/v2/pins/' + id, { headers: plexHeaders(ensurePlexClientId()) });
          if (up.status < 200 || up.status >= 300) return sendJSON(res, 502, { message: 'Plex returned HTTP ' + up.status });
          const j = JSON.parse(up.body.toString('utf8'));
          return sendJSON(res, 200, { authorized: !!j.authToken, token: j.authToken || '' });
        } catch (e) { return sendJSON(res, 502, { message: 'Could not reach Plex: ' + e.message }); }
      }
      if (p === '/api/admin/plex/servers' && req.method === 'POST') {
        let token = '';
        try { token = String((JSON.parse((await readBody(req)) || '{}').token) || '').trim(); } catch (e) {}
        if (!token) return sendJSON(res, 400, { message: 'Missing token' });
        try {
          const up = await upstream('https://plex.tv/api/v2/resources?includeHttps=1&includeRelay=1', { headers: plexHeaders(ensurePlexClientId(), token) });
          if (up.status < 200 || up.status >= 300) return sendJSON(res, 502, { message: 'Plex returned HTTP ' + up.status });
          const arr = JSON.parse(up.body.toString('utf8'));
          const servers = (Array.isArray(arr) ? arr : [])
            .filter(d => String(d.provides || '').split(',').includes('server'))
            .map(d => ({
              name: d.name, product: d.product || 'Plex Media Server', owned: !!d.owned, token: d.accessToken || token,
              connections: (d.connections || []).map(c => ({ uri: c.uri, address: c.address, port: c.port, protocol: c.protocol, local: !!c.local, relay: !!c.relay }))
            }));
          return sendJSON(res, 200, { servers });
        } catch (e) { return sendJSON(res, 502, { message: 'Could not reach Plex: ' + e.message }); }
      }

      // ---- WebDAV: browse a folder and download files (counts against the daily limit) ----
      if (p === '/api/webdav/list' && req.method === 'GET') return webdavList(u.searchParams.get('path') || '', res);
      if (p === '/api/webdav/stream' && req.method === 'GET') return webdavStream(u.searchParams.get('path') || '', req, res);
      if (p === '/api/webdav/tracks' && req.method === 'GET') return webdavTracks(u.searchParams.get('path') || '', res);
      if (p === '/api/webdav/subtitle' && req.method === 'GET') return webdavSubtitle(u.searchParams.get('path') || '', u.searchParams.get('sidx'), res);
      if (p === '/api/webdav/hls/start' && req.method === 'GET') return webdavHlsStart(u.searchParams.get('path') || '', { ac: u.searchParams.get('ac'), vc: u.searchParams.get('vc'), aidx: u.searchParams.get('aidx'), q: u.searchParams.get('q') }, res, req, me);
      if (p === '/api/webdav/hls/stop' && req.method === 'GET') return webdavHlsStop(u.searchParams.get('sid') || '', res);
      { const hm = p.match(/^\/api\/webdav\/hls\/([A-Za-z0-9]+)\/([A-Za-z0-9_.-]+)$/); if (hm && req.method === 'GET') return webdavHlsFile(hm[1], hm[2], res); }
      if (p === '/api/webdav/download' && (req.method === 'GET' || req.method === 'HEAD')) return webdavDownload(u.searchParams.get('path') || '', res, me, req.method === 'HEAD', req);

      // ---- admin: user management ----
      if (p === '/api/admin/users' && req.method === 'GET') {
        return sendJSON(res, 200, { users: readUsers().users.map(u => publicUser(u, true)) });
      }
      if (p === '/api/admin/users' && req.method === 'POST') {
        const { username, password, role, dailyLimit } = JSON.parse(await readBody(req) || '{}');
        if (!username || !password) return sendJSON(res, 400, { message: 'Username and password required' });
        const data = readUsers();
        if (data.users.find(u => u.username.toLowerCase() === String(username).toLowerCase())) return sendJSON(res, 400, { message: 'That username already exists' });
        const { salt, hash } = hashPassword(password);
        const u = { username: String(username).trim(), role: role === 'admin' ? 'admin' : 'user', dailyLimit: Number(dailyLimit) >= 0 ? Number(dailyLimit) : 10, salt, hash, createdAt: Date.now() };
        data.users.push(u); writeUsers(data);
        return sendJSON(res, 200, publicUser(u, true));
      }
      if (p === '/api/admin/users' && req.method === 'PATCH') {
        const { username, dailyLimit, role, password } = JSON.parse(await readBody(req) || '{}');
        const data = readUsers();
        const u = data.users.find(x => x.username.toLowerCase() === String(username).toLowerCase());
        if (!u) return sendJSON(res, 404, { message: 'User not found' });
        if (dailyLimit != null && Number(dailyLimit) >= 0) u.dailyLimit = Number(dailyLimit);
        if (role === 'admin' || role === 'user') {
          if (u.role === 'admin' && role === 'user' && data.users.filter(x => x.role === 'admin').length <= 1)
            return sendJSON(res, 400, { message: "Can't demote the last admin" });
          u.role = role;
        }
        if (password) { const { salt, hash } = hashPassword(password); u.salt = salt; u.hash = hash; }
        writeUsers(data);
        return sendJSON(res, 200, publicUser(u, true));
      }
      if (p === '/api/admin/users/delete' && req.method === 'POST') {
        const { username } = JSON.parse(await readBody(req) || '{}');
        const data = readUsers();
        const u = data.users.find(x => x.username.toLowerCase() === String(username).toLowerCase());
        if (!u) return sendJSON(res, 404, { message: 'User not found' });
        if (u.role === 'admin' && data.users.filter(x => x.role === 'admin').length <= 1) return sendJSON(res, 400, { message: "Can't remove the last admin" });
        if (u.username === me.username) return sendJSON(res, 400, { message: "You can't remove yourself" });
        data.users = data.users.filter(x => x !== u); writeUsers(data);
        return sendJSON(res, 200, { ok: true });
      }
      if (p === '/api/admin/adds' && req.method === 'GET') {
        const limit = Math.min(1000, Number(u.searchParams.get('limit')) || 200);
        const q = (u.searchParams.get('q') || '').trim().toLowerCase();
        const type = u.searchParams.get('type') || 'all';
        let list = readAdds().adds;
        if (type && type !== 'all') list = list.filter(e => type === 'add' ? (e.type === 'movie' || e.type === 'series') : e.type === type);
        if (q) list = list.filter(e => ((e.title || '') + ' ' + (e.username || '') + ' ' + (e.ip || '') + ' ' + (e.service || '') + ' ' + (e.type || '')).toLowerCase().includes(q));
        return sendJSON(res, 200, { adds: list.slice(0, limit), total: list.length });
      }

      // any logged-in user can change their own password
      if (p === '/api/change-password' && req.method === 'POST') {
        const { currentPassword, newPassword } = JSON.parse(await readBody(req) || '{}');
        if (!newPassword || String(newPassword).length < 4) return sendJSON(res, 400, { message: 'New password must be at least 4 characters' });
        if (!verifyPassword(currentPassword, me.salt, me.hash)) return sendJSON(res, 403, { message: 'Current password is incorrect' });
        const data = readUsers();
        const target = data.users.find(x => x.username.toLowerCase() === me.username.toLowerCase());
        const { salt, hash } = hashPassword(newPassword);
        target.salt = salt; target.hash = hash; writeUsers(data);
        return sendJSON(res, 200, { ok: true });
      }
    }

    // config
    if (p === '/api/config' && req.method === 'GET')  return sendJSON(res, 200, sanitize(readConfig()));
    if (p === '/api/config' && req.method === 'POST') {
      const incoming = JSON.parse(await readBody(req) || '{}');
      const cur = readConfig();
      for (const svc of ['radarr', 'sonarr']) {
        const s = incoming[svc]; if (!s) continue;
        if (s.url != null)              cur[svc].url = normUrl(s.url);
        if (s.apiKey)                   cur[svc].apiKey = s.apiKey;        // only overwrite when non-empty
        if (s.qualityProfileId != null) cur[svc].qualityProfileId = s.qualityProfileId;
        if (s.rootFolderPath != null)   cur[svc].rootFolderPath = s.rootFolderPath;
      }
      if (incoming.tmdb && incoming.tmdb.apiKey) cur.tmdb.apiKey = incoming.tmdb.apiKey;
      if (incoming.plex) {
        if (incoming.plex.url != null) cur.plex.url = normUrl(incoming.plex.url);
        if (incoming.plex.token)       cur.plex.token = incoming.plex.token;   // only overwrite when non-empty
      }
      if (incoming.webdav) {
        if (incoming.webdav.url != null)      cur.webdav.url = normUrl(incoming.webdav.url);
        if (incoming.webdav.username != null) cur.webdav.username = String(incoming.webdav.username).trim();
        if (incoming.webdav.password)         cur.webdav.password = incoming.webdav.password;   // only overwrite when non-empty
        if (incoming.webdav.folder != null)   cur.webdav.folder = String(incoming.webdav.folder).trim();
        if (incoming.webdav.mode != null)     cur.webdav.mode = wmode(incoming.webdav.mode);
        if (incoming.webdav.transcode != null) cur.webdav.transcode = !!incoming.webdav.transcode;
        if (incoming.webdav.encSpeed != null && ['balanced', 'faster', 'fastest', 'quality'].includes(incoming.webdav.encSpeed)) cur.webdav.encSpeed = incoming.webdav.encSpeed;
        if (incoming.webdav.hwAccel != null && ['auto', 'off'].includes(incoming.webdav.hwAccel)) cur.webdav.hwAccel = incoming.webdav.hwAccel;
      }
      if (incoming.ui && incoming.ui.loginTheme && LOGIN_THEMES.includes(incoming.ui.loginTheme)) {
        cur.ui.loginTheme = incoming.ui.loginTheme;
      }
      if (incoming.donate) {
        if (incoming.donate.url != null) {
          const du = String(incoming.donate.url).trim();
          if (du === '' || /^https?:\/\//i.test(du)) cur.donate.url = du;   // must be an http(s) link (or cleared)
        }
        if (incoming.donate.label != null) cur.donate.label = String(incoming.donate.label).trim().slice(0, 40);
      }
      if (incoming.autoAdd) {
        if (incoming.autoAdd.intervalMinutes != null) {
          const mins = Number(incoming.autoAdd.intervalMinutes);
          if (Number.isFinite(mins) && mins >= 0 && mins <= 1440) cur.autoAdd.intervalMinutes = mins;
        }
        if (incoming.autoAdd.minRuntime != null) {
          const mr = Number(incoming.autoAdd.minRuntime);
          if (Number.isFinite(mr) && mr >= 0 && mr <= 600) cur.autoAdd.minRuntime = mr;
        }
      }
      writeConfig(cur);
      return sendJSON(res, 200, sanitize(cur));
    }

    // test connection
    if (p === '/api/test' && req.method === 'POST') {
      const body = JSON.parse(await readBody(req) || '{}');
      const { svc, url, key } = body;
      try {
        if (svc === 'tmdb') return sendJSON(res, 200, await testTmdb(key));
        if (svc === 'plex') return sendJSON(res, 200, await testPlex(url, key));
        if (svc === 'webdav') return sendJSON(res, 200, await testWebdav(url, body.username, body.password, body.folder));
        if (['radarr', 'sonarr'].includes(svc)) return sendJSON(res, 200, await testService(svc, url, key));
        return sendJSON(res, 400, { message: 'bad service' });
      } catch (e) {
        const hint = /ECONNREFUSED|timed out|ENOTFOUND|EHOSTUNREACH/.test(e.message) ? ' (is the URL/port correct and the server running?)' : '';
        return sendJSON(res, 502, { message: e.message + hint });
      }
    }

    // health report
    if (p === '/api/health' && req.method === 'GET') {
      if (u.searchParams.get('refresh')) await runAllChecks();
      return sendJSON(res, 200, {
        services: healthState.services,
        events: healthState.events,
        monitored: monitoredTargets().map(t => t.name),
        intervalMs: HEALTH_INTERVAL_MS,
        now: Date.now()
      });
    }

    // plex now-streaming (privacy-trimmed server-side: 4-char user, no IP)
    if (p === '/api/streams' && req.method === 'GET') {
      return sendJSON(res, 200, await plexSessions());
    }

    // proxies
    if (p.startsWith('/api/radarr/'))   return proxyArr('radarr', p.slice('/api/radarr'.length) + u.search, req, res);
    if (p.startsWith('/api/sonarr/'))   return proxyArr('sonarr', p.slice('/api/sonarr'.length) + u.search, req, res);
    if (p.startsWith('/api/cinemeta/')) return proxyCinemeta(p.slice('/api/cinemeta'.length) + u.search, res);
    if (p.startsWith('/api/tmdb/'))     return proxyTmdb(p.slice('/api/tmdb'.length) + u.search, res);
    if (p.startsWith('/api/plex/'))     return proxyPlex(p.slice('/api/plex'.length) + u.search, res);

    // other static assets under public/
    if (req.method === 'GET') return serveStatic(res, p.replace(/^\//, ''));

    res.writeHead(404); res.end('Not found');
  } catch (e) {
    sendJSON(res, 500, { message: e.message });
  }
});

server.listen(PORT, HOST, () => {
  console.log('\n  MEDIARR running →  http://localhost:' + PORT + '\n');
  console.log('  Config stored at:  ' + CONFIG_PATH);
  console.log('  Health log at:     ' + HEALTH_PATH);
  console.log('  Stop with Ctrl+C\n');
  // background health monitoring: first run shortly after boot, then on an interval
  setTimeout(() => { runAllChecks().catch(() => {}); }, 2500);
  setInterval(() => { runAllChecks().catch(() => {}); }, HEALTH_INTERVAL_MS);
});
