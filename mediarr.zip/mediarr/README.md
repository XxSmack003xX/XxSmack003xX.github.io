# MEDIARR

A tiny self-hosted web app to search **Stremio Cinemeta** for movies & TV shows and push them
straight into **Radarr** (movies) or **Sonarr** (TV — adds & monitors every episode).

A small Node.js server serves the page and **proxies** all API calls, so there are no CORS or
mixed-content problems, and your credentials are stored on your own machine.

## Requirements
- Node.js 18 or newer (no npm packages to install — it uses only Node built-ins).

## Run
```bash
cd mediarr
node server.js
```
Then open **http://localhost:7575** in your browser.

## Accounts & the admin panel
The first time you open MEDIARR you'll be asked to **create an administrator account**. After that,
everyone signs in on the login screen.

- **Admins** can do everything: configure servers (Settings), view Health/Streams, and open the
  **Admin** panel.
- **Regular users** can search and add, but are capped at a **daily add limit** (10 by default) and
  can't see Settings or Admin. Their remaining adds for the day show next to their name (e.g. `3/10`).
  They also can't change a title's Radarr/Sonarr options or monitoring — the edit panel, the monitor
  scheme dropdown, and the per-season/episode controls are hidden for them, and those operations are
  blocked server-side too (not just hidden), so they only get search + add.
- In the **Admin** panel you can add and remove users, switch a user between regular/admin, raise or
  lower each user's daily limit, and see a **log of what every regular user has added** to Radarr or
  Sonarr (title, service, and time).

Passwords are stored hashed (scrypt) in `users.json`; logins use an HttpOnly session cookie that
**expires after 1 hour**, after which the app drops you back to the login screen automatically. To
change that window, start the server with `SESSION_HOURS` set (e.g. `SESSION_HOURS=8 node server.js`,
or `SESSION_HOURS=0.5` for 30 minutes). Any user (admin or regular) can change their own password
with the **Password** button in the header (it asks for the current password first). The add log
lives in `adds.json`. Both sit next to `server.js`. Sessions are kept in memory, so a server restart
also signs everyone out.

To use a different port:
```bash
PORT=8080 node server.js
```

## First run
On first launch you'll be prompted for each service:
1. **Server URL / IP** — e.g. `http://192.168.1.10:7878` (Radarr) and `http://192.168.1.10:8989` (Sonarr).
2. **API Key** — in Radarr/Sonarr under **Settings → General → Security**.

There's also an optional **TMDB** key (see below). Click **Test & load options** to verify a
connection and auto-fill the quality-profile and root-folder dropdowns, then **Save**.

## Mobile app (Bootstrap 5) — `/m`
There's a separate, touch‑friendly mobile interface built with **Bootstrap 5**, served at **`/m`**.
Phones and tablets are auto‑redirected there from `/` (by user‑agent); the desktop UI at `/` is
unchanged. On mobile there's a "Use the desktop site" link, and `/?d=1` always forces the desktop UI.

**Bootstrap loads automatically.** The first time you open `/m` while the box has internet, the
server downloads Bootstrap from the CDN and caches it into `public/` (`bootstrap.min.css` and
`bootstrap.bundle.min.js`), then serves it locally from then on — so it works offline after that
first load. If your box can't reach the internet at all, drop those two files into `public/` yourself
(from https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/ or the GitHub release `dist/` folder).

What the mobile app covers: login/setup, the **Title / Person / Year / Studio** search with a
"Recently released" home feed, results as cards with Add‑to‑Radarr/Sonarr and library ✓ markers, a
detail view (overview + add with monitor scheme / minimum availability), and the full desktop menu —
**Now streaming**, **Movies** and **Shows** library browsers (with per‑item 🔍 search), **Calendar**
(7/14/30‑day), **Health** (with outage history and refresh), **Admin** (user management + add log),
**Change password**, and **Settings**. Admin‑only items appear only for admins, matching the desktop.

## Search by actor / director / year / studio (TMDB)
Use the **🎬 Title / 👤 Person / 📅 Year / 🏢 Studio** toggle above the search box. In **Person** mode you search by
name, pick the actor or director, and get their full filmography (movies + TV, newest first),
each tagged **Actor** or **Director**. Every card has its own **＋ Add to Radarr/Sonarr** button
and shows a ✓ if it's already in your library; clicking the card opens the usual detail view.

In **Year** mode, type a 4-digit year (e.g. `1999`) and MEDIARR lists every movie and show released
that year, most popular first, with the same Add buttons, ✓ markers, and click-to-detail. Use the
All / Movies / TV filter to narrow it, and **Load more** to page through the full list.

In **Studio** mode, type a studio name (e.g. `Pixar`, `Warner Bros`, `A24`, `Studio Ghibli`) and
MEDIARR lists that studio's movies, most popular first. It matches the studio across its sub-companies
(so "Disney" includes Walt Disney Pictures, Animation, etc.), with the same Add buttons, ✓ markers,
click-to-detail, and **Load more**.

Person, Year, and Studio search all need a free **TMDB API key** (Cinemeta has no person, discover, or
company data). Get one at themoviedb.org → Settings → API, paste it into **Settings → TMDB**, and click
**Test key**. The key is stored server-side in `config.json` like the others — everything else
works without it.

## Cast & crew in the detail view
Open any movie or show and you'll see its **director (or creator) with a headshot** and the **full
cast with photos and character names**. Click any face to jump straight to that person's
filmography. Photos come from TMDB, so this needs the TMDB key; without it the detail view still
lists the director and cast names that Cinemeta provides (no photos).

## Plex health monitoring
Add your **Plex** server in **Settings → Plex** (URL like `http://IP:32400` plus your
`X-Plex-Token`). While MEDIARR is running it checks Plex — and Radarr/Sonarr if configured —
every 60 seconds in the background and records every status change to `health.json` next to the
server.

Click **Health** in the header for the report: each server shows **Online/Offline**, version,
response time, and how long it's been in that state. Below that, an **outage history** lists every
time a server went down, **with timestamps** for when it dropped and when it recovered (plus the
outage duration). A server that's currently down shows a pulsing marker and a running counter.
**Download report** saves a plain-text snapshot. The history survives restarts because it's stored
on disk, so MEDIARR keeps logging downtime even across reboots (whenever it's running).

Finding your token: https://support.plex.tv/articles/204059436-finding-an-authentication-token-x-plex-token/

## Discovery (needs a TMDB key)
- **Recently released on the home screen:** as soon as you log in (and whenever the search box is
  empty), the main page shows a "Recently released" row of movies currently in theaters, pulled from
  TMDB. Click one to open its details or add it.
- **Similar titles:** open any movie or show and scroll down to a **Similar movies / Similar shows**
  row (TMDB recommendations, with a "similar" fallback). Click one to jump straight into its detail
  view — which shows its own recommendations, so you can keep exploring.

## Library browsers (manual search)
Two header buttons — **Movies** (Radarr) and **Shows** (Sonarr), admin‑only — open a window listing
everything you've added, with a title filter and a download/missing (or episode‑count) indicator on
each row. Every row has a **🔍 search button** that tells Radarr/Sonarr to search for that whole
movie or show right now; clicking a title opens its full detail view. There's also a **Search all
monitored** button (with a confirmation, since it can hammer your indexers).

## Upcoming calendar
The **Calendar** button (top bar) shows what's coming up, pulled live from Radarr's and Sonarr's
`/calendar` APIs and merged into a single day‑by‑day agenda. Movies show their release type (In
Cinemas / Digital / Physical) and TV shows the season/episode, episode title, and air time. Filter
by All / Movies / TV and switch the window between 7, 30, and 90 days. Already‑downloaded items are
badged, and clicking any row opens that title's full detail view (cast, episodes, edit options).
Available to every signed‑in user.

## WebDAV downloads
Under **Settings → WebDAV** (admin only) you can point MEDIARR at a WebDAV server and a folder. Enter the
server URL, username, password, and the folder to browse, then **Test connection** to confirm and see how
many videos are found. Once saved, a **Downloads** button appears (for every logged-in user) in the header
on desktop and in the menu on mobile.

The Downloads view lists the sub-folders and video files in that folder; click a folder to go deeper,
**Play** a video to watch it in the browser, or **Download** it to save to your device. **Every download
counts against the user's daily limit** — the same per-user limit used for adding to Radarr/Sonarr (admins
are unlimited). When a user is out of quota the download is blocked with a "daily limit reached" message,
and each download is recorded in the admin add-log. **Playback** streams through MEDIARR with seek/range
support and does *not* count against the limit; browser-native formats (mp4, webm, mov) play inline, while
formats like .mkv/.avi may not play in the browser, in which case the player offers a download instead.

### Incompatible audio or video (5.1/AC3/DTS, HEVC/H.265, 10-bit, …)
Browsers can only decode a handful of codecs — AAC/MP3/Opus/Vorbis/FLAC for audio and H.264/VP8/VP9/AV1 for
video. Surround audio (AC3, E-AC3, DTS, TrueHD) and many video codecs (HEVC/H.265, MPEG-2, VC-1, 10-bit
"Hi10P" H.264) won't play directly. If **ffmpeg** is installed on the server, MEDIARR transcodes on the fly.

**Direct play vs. transcode.** When the **Quality** is left at **Original** and no toggles are set, a
compatible file streams directly from WebDAV with byte-range requests — zero CPU and instant seeking, at full
original quality. The moment you need transcoding (an incompatible codec, a different audio track, a stereo
downmix, or a lower quality), MEDIARR switches to a transcoded stream.

**Seeking works in transcode mode.** Transcoded playback is delivered as a **seekable VOD HLS** stream: the
full timeline is known up front, so you can scrub anywhere. Segments are produced on demand, and when you jump
to a point that hasn't been encoded yet the encoder restarts at that spot (timestamps are preserved so the
timeline stays aligned). There may be a second or two of delay right at a fresh seek point while the encoder
catches up. Playback uses **hls.js** on desktop/Android browsers and native HLS on iOS/Safari; if neither is
available it falls back to a non-seekable progressive stream. (hls.js is fetched from a CDN and cached locally
on first use, like Bootstrap.)

**Quality presets.** The player's **Quality** dropdown offers **Original** (no resolution change — visually
lossless), **1080p (High)**, **720p (Medium)** and **480p (Low)**. Lower tiers cap the resolution (downscale
only — they never upscale) and lower the bitrate, which is useful on slow connections or weak devices. Note
that any transcoded quality re-encodes the video to H.264 with aligned keyframes (needed for seekable
segments), so it uses CPU; **Original + direct play** is the only path that copies the video untouched.
Surround audio becomes AAC (5.1 preserved where the browser supports it, or **Downmix to stereo** for players
like Firefox). The **Transcode** toggle forces a transcode at the chosen quality (e.g. to fix audio without
changing resolution), and **Settings → WebDAV → Default to transcoded playback** turns it on by default.
Transcoding uses libx264 `veryfast` with no hardware acceleration; if ffmpeg isn't installed these options are
hidden and playback stays direct. HLS segments live in a temp folder under the system temp dir and are cleaned
up automatically when playback ends or goes idle.

**Audio & subtitle tracks:** when a file has more than one audio track, or has text subtitle tracks, the
player shows **Audio** and **Subtitles** dropdowns (requires ffmpeg/ffprobe). Picking a different audio track
re-muxes that track on the fly (so it engages transcoding). Subtitles are extracted to WebVTT and shown as a
toggleable caption track — no video re-encode needed. Only text subtitles (SRT/ASS/SSA/mov_text/…) can be
shown this way; image-based subtitles (PGS/VobSub) aren't offered. On iPhone/iPad, subtitle captions may not
appear during transcoded HLS playback (an iOS limitation); audio-track selection works on all platforms.

**Download method** (Settings → WebDAV) controls where the bytes come from:
- **Direct — browser asks for login (default, recommended):** MEDIARR authorizes and counts the download, then
  redirects your browser straight to the WebDAV file. Your browser handles the WebDAV login itself (a native
  prompt the first time each session, cached after), so credentials never appear in a link and MEDIARR never
  relays the file. Works with Basic-auth WebDAV servers like NzbDAV.
- **Through MEDIARR (proxy):** the file is streamed through the MEDIARR server. Use this if your WebDAV is plain
  HTTP behind an HTTPS MEDIARR (where a browser would block a direct redirect as mixed content).
- **Direct — embed login in link:** seamless with no prompt, but your WebDAV username/password are visible in the
  download URL — only use on networks you trust.

## Who's streaming (Plex)
Next to **Health** is a **▶ N streaming** button showing how many Plex streams are active right now
(it refreshes every 30s). Click it to see what each person is watching: movies show the title and
year; TV shows show the series with **S01E02 · Episode Title**, plus play/pause state and progress.
For privacy, usernames are trimmed to their first four characters and **IP addresses are never sent
to the browser** — the trimming happens on the server before the data ever leaves it.

Credentials are written to `config.json` next to `server.js` and reused on every future launch,
so you won't be asked again. Use the **Settings** button (top right) to change them anytime.

## How adding works
- **Movies → Radarr:** when adding a movie you pick its **minimum availability** — Announced, In
  Cinemas, or Released — which controls when Radarr starts grabbing it, plus whether to search right
  away. The same dropdown is in a movie's edit panel so you can change it later.
- **TV → Sonarr:** when adding a series you pick a **Monitor** scheme — All / Future / Missing /
  Existing / Recent / Pilot / First Season / Last Season / None — plus whether to start a search
  right away. A live progress feed shows each season's episodes being registered.
- **Changing monitoring later:** in the edit panel of a series already in Sonarr there's a
  **Re-apply monitoring** dropdown with the same schemes; pick one and hit **Apply** to flip which
  episodes are monitored (e.g. switch a finished show to "Existing" or a current one to "Future").

## Already-added items & editing options
- On launch (and after any add) MEDIARR pulls your full Radarr and Sonarr libraries and shows a
  green **✓** on any search result you already have. Use the **Hide added** toggle next to the
  filters to drop everything already in your library from the results — it works in Title, Year,
  and person-filmography views and updates live as you add things.
- Open an item that's already in your library and you get an **edit panel** instead of an Add
  button: change its **quality profile**, **root folder**, and **monitored** state, optionally
  **move existing files** when the root folder changes, then **Save changes**. There's also a
  **Search now** button to make Radarr/Sonarr immediately look for releases.

## Per-season and per-episode control (Sonarr)
For a TV series that's already in Sonarr, the episode list is loaded live from Sonarr and each
row shows its status (downloaded ●green, monitored ●gold, unmonitored ○grey). You can:
- **Add season** — monitors the whole season (and its episodes) and triggers a season search.
- **Search** (per season) — re-runs a search without changing monitoring.
- **Add** (per episode) — monitors that one episode and searches for it; downloaded episodes show a ✓.

If a series isn't in Sonarr yet, use **"Add series only, then pick seasons / episodes"** to add it
with nothing monitored — the view reloads with the per-season/episode controls so you can choose
exactly what to grab. (The plain **Add to Sonarr (all episodes)** button still monitors everything.)

## Login screen themes
The login page has an animated background, and an admin can pick which one in **Settings →
Appearance → Login screen theme**:
- **Tron** — a neon perspective grid with a synthwave sun, scanlines, and Tron light‑cycle trails.
- **Earth** — the planet rising in the lower corner with a glowing atmosphere, drifting nebulas,
  twinkling stars, and shooting stars.
- **Rainy NYC** — a night photo of the NYC skyline seen through a fogged window: realistic water
  droplets cling to the glass and roll down (each acting like a little lens that reveals the sharp
  view through the mist), wet streaks dry behind them, rain falls, and forked lightning flashes
  light up the scene. The photo loads from the web; if it can't be reached it falls back to a drawn
  skyline so the theme still works offline.
- **Randomize** — picks one of the above at random every time the login screen appears.

The choice is saved server‑side and shown to everyone on the login page (it loads before sign‑in).
The animation only runs while the login screen is visible and stops once you're in, so it uses no
CPU during normal use.

## Behind a reverse proxy (DuckDNS + Caddy)
MEDIARR works behind Caddy with HTTPS on a DuckDNS domain out of the box — all paths are relative
and Radarr/Sonarr/Plex calls go through the built-in same-origin proxy, so there's no mixed-content
issue. A ready-to-edit `Caddyfile.example` is included. Quick version:

1. Run MEDIARR bound to localhost so only Caddy can reach it:
   ```bash
   HOST=127.0.0.1 PORT=7575 node server.js
   ```
2. Use a Caddyfile like:
   ```
   MYNAME.duckdns.org {
       encode zstd gzip
       reverse_proxy 127.0.0.1:7575
   }
   ```
   Caddy obtains the HTTPS certificate automatically. If your ISP blocks port 80, use the DNS
   challenge instead (a Caddy build with the `caddy-dns/duckdns` module and a `tls { dns duckdns
   <token> }` block — see `Caddyfile.example`).

MEDIARR reads `X-Forwarded-Proto` (which Caddy sets) and marks the session cookie **Secure** when
you're on HTTPS, while leaving it non-Secure on plain `http://localhost` so local use still works.
You can force Secure cookies with `SECURE_COOKIES=1` if you terminate TLS some other way.

**Troubleshooting** — if the login screen shows a JSON parse error like *"unexpected end of data"*,
the reverse proxy isn't forwarding `/api` requests to MEDIARR (it's serving files itself or 502-ing).
Use a single `reverse_proxy` for the whole site (as in `Caddyfile.example`) — MEDIARR serves both
its HTML and its API, so don't mix in `file_server` or path matchers. MEDIARR now detects this and
shows a clear message pointing at the proxy instead of a raw parse error.

## Notes
- `config.json` holds your API keys in plain text on your machine (same as Radarr/Sonarr's own
  configs). Keep the folder private. The server never sends raw keys back to the browser.
- The server binds to `0.0.0.0` so you can reach it from other devices on your LAN. Set
  `HOST=127.0.0.1` if you want it accessible only from the local machine.
- Not affiliated with Radarr, Sonarr, or Stremio.
